#!/usr/bin/env python3
"""Generate the untimed counter patch, or reduce its per-block lines."""
from difflib import unified_diff
from pathlib import Path
import subprocess as sp
import sys

if len(sys.argv) > 1:
    for path in map(Path, sys.argv[1:]):
        fields = ('blocks', 'ext20_64', 'fast32', 'fast64', 'distance1', 'distance1_bytes', 'tokens', 'plain')
        rows = [list(map(int, ln.split()[1:])) for ln in path.read_text().splitlines() if ln.startswith('CENSUS ')]
        assert rows and all(len(r) == len(fields) for r in rows)
        # verify first reconstructs and rejects a bad checksum on the middle
        # block, then replays every block once in sequence.
        rows = rows[1:]
        print(path.name, dict(zip(fields, map(sum, zip(*rows)))))
    sys.exit()

path = 'crates/codec/src/block.rs'
pin = 'dac698f924ecbe452432425e9047f61b6e118065'
old = sp.check_output(['git', 'show', f'{pin}:{path}'], text=True)
new = old


def insert(before, after):
    global new
    assert new.count(before) == 1, before
    new = new.replace(before, after)


insert('    } else {\n        reconstruct::<15, _>(\n            Spl16',
       '    } else {\n        let result = reconstruct::<15, _>(\n            Spl16')
insert('            out,\n        )?\n    };\n    crate::probe!',
       '''            out,
        )?;
        eprintln!(" {n} {result}");
        result
    };
    crate::probe!''')
insert('    let mut match_budget = limit - lit.len();', '''    let [mut ext, mut fast32, mut fast64, mut dist1, mut fill_bytes] = [0; 5];
    let mut match_budget = limit - lit.len();''')
insert('                out.copy_within(m - off..m - off + 64, m);', '''                out.copy_within(m - off..m - off + 64, m);
                ext += 1;
                if len <= 32 { fast32 += 1; } else { fast64 += 1; }''')
insert('        let off = usize::from(off) + 1;\n        require(ml <= match_budget',
       '''        if S::SPL16 && (20..=64).contains(&ml) { ext += 1; }
        let off = usize::from(off) + 1;
        require(ml <= match_budget''')
insert('        if off > pos {', '''        if S::SPL16 && off == 1 && off <= pos {
            dist1 += 1;
            fill_bytes += ml;
        }
        if off > pos {''')
insert('    Ok(pos + lit.len())\n}', '''    if S::SPL16 { eprint!("CENSUS 1 {ext} {fast32} {fast64} {dist1} {fill_bytes}"); }
    Ok(pos + lit.len())
}''')
# Emission appends the token and plaintext columns after the reconstruction counters.
print(''.join(unified_diff(old.splitlines(True), new.splitlines(True), f'a/{path}', f'b/{path}')), end='')
