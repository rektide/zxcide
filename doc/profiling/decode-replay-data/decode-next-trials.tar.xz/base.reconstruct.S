000000000001de40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>>:
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:372
   1de40:	push   %rbp
   1de41:	push   %r15
   1de43:	push   %r14
   1de45:	push   %r13
   1de47:	push   %r12
   1de49:	push   %rbx
   1de4a:	sub    $0x78,%rsp
   1de4e:	mov    %rdx,%rbp
   1de51:	mov    %rsi,0x18(%rsp)
   1de56:	mov    0xc0(%rsp),%r13
   1de5e:	mov    %rcx,0x68(%rsp)
   1de63:	mov    %r8,0x70(%rsp)
   1de68:	mov    0x20(%rdi),%rax
   1de6c:	mov    0x28(%rdi),%rcx
   1de70:	mov    %rcx,0x58(%rsp)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1de75:	cmp    %rcx,%rax
next<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1de78:	jae    1deac <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x6c>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1de7a:	mov    %r9,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:380
   1de7d:	mov    %r9,%rcx
   1de80:	sub    %rbp,%rcx
   1de83:	mov    %rcx,0x38(%rsp)
   1de88:	mov    (%rdi),%rcx
   1de8b:	mov    %rcx,0x50(%rsp)
   1de90:	mov    0x10(%rdi),%rcx
   1de94:	mov    %rcx,0x48(%rsp)
   1de99:	movq   $0x0,0x8(%rsp)
   1dea2:	xor    %r15d,%r15d
   1dea5:	mov    %r9,0x40(%rsp)
   1deaa:	jmp    1df14 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xd4>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1deac:	mov    0x10(%r13),%r9
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1deb0:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:502
   1deb3:	mov    %r15,%rbx
   1deb6:	add    %rbp,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1deb9:	jb     1e331 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4f1>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1debf:	cmp    %r9,%rbx
   1dec2:	ja     1e331 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4f1>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1dec8:	add    0x8(%r13),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1decc:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1decf:	mov    0x18(%rsp),%rsi
   1ded4:	mov    %rbp,%rdx
   1ded7:	call   *0x4a9a3(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1dedd:	xor    %eax,%eax
   1dedf:	jmp    1e2f0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4b0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1dee4:	movups (%rdi,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1dee8:	movups %xmm0,(%rdi,%r12,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:474
   1deed:	add    %r12,%r14
   1def0:	mov    %r14,%r15
   1def3:	mov    0x60(%rsp),%rax
   1def8:	inc    %rax
next<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1defb:	cmp    0x58(%rsp),%rax
   1df00:	mov    0x10(%rsp),%rbp
   1df05:	mov    0xc0(%rsp),%r13
   1df0d:	mov    0x40(%rsp),%r12
   1df12:	je     1deb3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x73>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1df14:	mov    0x50(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ops/function.rs:310
   1df19:	movzbl (%rcx,%rax,1),%r14d
call_once<((&u8, &u8)), zxc_codec::block::unpack_with_sections::{closure_env#2}>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ops/function.rs:310
   1df1e:	mov    %rax,0x60(%rsp)
   1df23:	mov    0x48(%rsp),%rcx
   1df28:	movzbl (%rcx,%rax,1),%edi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:254
   1df2c:	mov    %r14d,%ebx
{closure#2}():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:254
   1df2f:	shr    $0x4,%ebx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:420
   1df32:	cmp    $0xf,%rbx
   1df36:	mov    %rdi,0x10(%rsp)
   1df3b:	jne    1df5b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x11b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1df3d:	lea    0x68(%rsp),%rdi
   1df42:	call   20190 <zxc_codec::block::extra>
   1df47:	mov    %rdx,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1df4a:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1df4c:	jne    1e2eb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4ab>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1df52:	add    $0xf,%rbx
   1df56:	mov    0x10(%rsp),%rdi
   1df5b:	and    $0xf,%r14d
   1df5f:	mov    %edi,%eax
   1df61:	shl    $0x10,%eax
   1df64:	shl    $0x8,%r14d
   1df68:	or     %eax,%r14d
   1df6b:	shr    $0x8,%r14d
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1df6f:	movzbl %r14b,%r14d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:423
   1df73:	add    $0x5,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:424
   1df77:	cmp    $0x14,%r14
   1df7b:	jne    1df9b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x15b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1df7d:	lea    0x68(%rsp),%rdi
   1df82:	call   20190 <zxc_codec::block::extra>
   1df87:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1df8a:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1df8c:	jne    1e2c7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x487>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1df92:	add    $0x14,%r14
   1df96:	mov    0x10(%rsp),%rdi
   1df9b:	mov    0x38(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:428
   1dfa0:	sub    %r14,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:74
   1dfa3:	jb     1e2ab <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x46b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:432
   1dfa9:	mov    %r12,%rax
   1dfac:	mov    %rcx,0x38(%rsp)
   1dfb1:	sub    %rcx,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1dfb4:	mov    0x10(%r13),%r9
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:433
   1dfb8:	cmp    %r9,%rax
   1dfbb:	jbe    1e01c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1dc>
   1dfbd:	mov    %r12,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:434
   1dfc0:	lea    (%r9,%r9,1),%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1dfc4:	cmp    %r12,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1dfc7:	cmova  %rax,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1dfcb:	cmp    %rcx,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1dfce:	cmovae %rcx,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1dfd2:	cmp    %r9,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1dfd5:	jbe    1e010 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1d0>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1dfd7:	sub    %r9,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1dfda:	mov    0x0(%r13),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1dfde:	sub    %r9,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1dfe1:	cmp    %rax,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1dfe4:	ja     1e289 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x449>
   1dfea:	mov    %r9,(%rsp)
spec_extend_with<u8, alloc::alloc::Global>():
   1dfee:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1dff2:	add    %r9,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1dff5:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1dff7:	mov    %r12,%rdx
   1dffa:	call   *0x4aa00(%rip)        # 68a00 <memset@GLIBC_2.2.5>
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1e000:	add    (%rsp),%r12
   1e004:	mov    0x10(%rsp),%rdi
   1e009:	jmp    1e015 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1d5>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e00b:	nopl   0x0(%rax,%rax,1)
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1e010:	cmp    %r9,%r12
   1e013:	jae    1e01c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1dc>
resize<u8, alloc::alloc::Global>():
   1e015:	mov    %r12,0x10(%r13)
   1e019:	mov    %r12,%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:436
   1e01c:	lea    (%rbx,%r15,1),%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1e020:	cmp    $0x8,%rbx
   1e024:	mov    %r9,(%rsp)
   1e028:	ja     1e042 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x202>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:449
   1e02a:	lea    0x8(%r15),%rsi
   1e02e:	cmp    %r9,%rsi
   1e031:	ja     1e03d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1fd>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e033:	cmp    $0x8,%rbp
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e037:	jae    1e22e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3ee>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:454
   1e03d:	test   %rbx,%rbx
   1e040:	je     1e094 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x254>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e042:	sub    %rbx,%rbp
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e045:	jb     1e2b9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x479>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e04b:	cmp    %r15,%r12
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e04e:	jb     1e31b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4db>
   1e054:	cmp    %r9,%r12
   1e057:	ja     1e31b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4db>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e05d:	mov    0x18(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1e062:	lea    (%rsi,%rbx,1),%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e066:	mov    0xc0(%rsp),%rax
get_offset_len_mut_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e06e:	add    0x8(%rax),%r15
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e072:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e075:	mov    %rbx,%rdx
   1e078:	call   *0x4a802(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1e07e:	mov    0x10(%rsp),%rdi
   1e083:	mov    (%rsp),%r9
   1e087:	mov    %r13,0x18(%rsp)
   1e08c:	mov    0xc0(%rsp),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e094:	inc    %edi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:459
   1e096:	mov    %r12,%rsi
   1e099:	sub    %rdi,%rsi
   1e09c:	mov    %rbp,0x10(%rsp)
   1e0a1:	jb     1e100 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x2c0>
   1e0a3:	cmp    %rdi,%r14
   1e0a6:	ja     1e100 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x2c0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1e0a8:	cmp    $0x9,%r14
   1e0ac:	jae    1e1e0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3a0>
   1e0b2:	lea    0x8(%r12),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e0b7:	mov    0x8(%r13),%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1e0bb:	cmp    %r9,%rax
   1e0be:	ja     1e1ea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3aa>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:468
   1e0c4:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e0c8:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e0cb:	jb     1e471 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x631>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e0d1:	cmp    $0xfffffffffffffff8,%rsi
   1e0d5:	jae    1e465 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x625>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e0db:	lea    -0x8(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e0df:	cmp    %rax,%r12
   1e0e2:	ja     1e389 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x549>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e0e8:	mov    (%rdi,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e0ec:	mov    %rax,(%rdi,%r12,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1e0f0:	jmp    1deed <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xad>
   1e0f5:	data16 cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:477
   1e100:	cmp    %rdi,%r12
   1e103:	jae    1e170 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x330>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:480
   1e105:	mov    %rdi,%r13
   1e108:	sub    %r12,%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e10b:	mov    0xb8(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e113:	sub    %r13,%rsi
   1e116:	jb     1e2d1 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x491>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e11c:	cmp    %r13,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e11f:	cmovb  %r14,%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:486
   1e123:	lea    (%r12,%r13,1),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e127:	cmp    %r9,%r15
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e12a:	ja     1e360 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x520>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e130:	mov    0xc0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e138:	mov    0x8(%rax),%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e13c:	add    %rbx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e13f:	add    0xb0(%rsp),%rsi
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e147:	mov    %rdi,%rbp
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e14a:	mov    %r12,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e14d:	mov    %r13,%rdx
   1e150:	call   *0x4a72a(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1e156:	mov    %rbp,%rdi
   1e159:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:489
   1e15d:	sub    %r13,%r14
   1e160:	jne    1e180 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x340>
   1e162:	jmp    1def3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
   1e167:	nopw   0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1e170:	test   %r14,%r14
   1e173:	je     1e281 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x441>
   1e179:	mov    0x8(%r13),%rbx
   1e17d:	mov    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:493
   1e180:	mov    %r15,%rbp
   1e183:	sub    %rdi,%rbp
   1e186:	lea    (%rbx,%rbp,1),%r13
   1e18a:	nopw   0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:496
   1e190:	mov    %r15,%r12
   1e193:	sub    %rbp,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e196:	cmp    %r12,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e199:	cmovb  %r14,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:497
   1e19d:	lea    (%r12,%rbp,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e1a1:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e1a4:	jb     1e3c7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x587>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e1aa:	cmp    %rax,%rbp
   1e1ad:	ja     1e3bb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x57b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e1b3:	sub    %r12,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e1b6:	cmp    %r9,%r15
   1e1b9:	ja     1e302 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4c2>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1e1bf:	lea    (%rbx,%r15,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e1c3:	mov    %r13,%rsi
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e1c6:	mov    %r12,%rdx
   1e1c9:	call   *0x4a839(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1e1cf:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:498
   1e1d3:	add    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1e1d6:	sub    %r12,%r14
   1e1d9:	jne    1e190 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x350>
   1e1db:	jmp    1def3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e1e0:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:469
   1e1e4:	cmp    $0x11,%r14
   1e1e8:	jae    1e1f4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3b4>
   1e1ea:	lea    0x10(%r12),%rax
   1e1ef:	cmp    %r9,%rax
   1e1f2:	jbe    1e258 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x418>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:472
   1e1f4:	lea    (%r14,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e1f8:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e1fb:	jb     1e3ff <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5bf>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e201:	cmp    %rax,%rsi
   1e204:	ja     1e3f3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5b3>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e20a:	sub    %r14,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e20d:	cmp    %r9,%r12
   1e210:	ja     1e347 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x507>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1e216:	add    %rdi,%rsi
   1e219:	add    %r12,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e21c:	mov    %r14,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e21f:	call   *0x4a7e3(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1e225:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:469
   1e229:	jmp    1deed <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xad>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e22e:	cmp    $0xfffffffffffffff8,%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e232:	jae    1e376 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x536>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e238:	mov    0x8(%r13),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e23c:	mov    0x18(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e241:	mov    (%rdx),%rcx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e244:	mov    %rcx,(%rax,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e248:	sub    %rbx,%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e24b:	add    %rbx,%rdx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e24e:	mov    %rdx,0x18(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1e253:	jmp    1e094 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x254>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:470
   1e258:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e25c:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e25f:	jb     1e438 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5f8>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e265:	cmp    $0xfffffffffffffff0,%rsi
   1e269:	jae    1e42c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5ec>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e26f:	lea    -0x10(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e273:	cmp    %rax,%r12
   1e276:	jbe    1dee4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xa4>
   1e27c:	jmp    1e3a2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x562>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e281:	mov    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1e284:	jmp    1def3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1e289:	mov    $0x1,%ecx
   1e28e:	mov    $0x1,%r8d
   1e294:	mov    %r13,%rdi
   1e297:	mov    %r9,%rsi
   1e29a:	mov    %r12,%rdx
   1e29d:	call   26430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1e2a2:	mov    0x10(%r13),%r9
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1e2a6:	jmp    1dfea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1aa>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2ab:	lea    -0x12915(%rip),%rsi        # b99d <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2b2:	mov    $0x18,%edx
   1e2b7:	jmp    1e2dd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x49d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2b9:	lea    -0x113d9(%rip),%rsi        # cee7 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.1069639741503911768>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2c0:	mov    $0xd,%edx
   1e2c5:	jmp    1e2dd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x49d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e2c7:	mov    $0x1,%eax
   1e2cc:	mov    %r14,%rbx
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e2cf:	jmp    1e2f0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4b0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2d1:	lea    -0x12923(%rip),%rsi        # b9b5 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1e2d8:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e2dd:	mov    $0x15,%edi
   1e2e2:	call   *0x4a728(%rip)        # 68a10 <_DYNAMIC+0x460>
   1e2e8:	mov    %rax,%rbx
   1e2eb:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:504
   1e2f0:	mov    %rbx,%rdx
   1e2f3:	add    $0x78,%rsp
   1e2f7:	pop    %rbx
   1e2f8:	pop    %r12
   1e2fa:	pop    %r13
   1e2fc:	pop    %r14
   1e2fe:	pop    %r15
   1e300:	pop    %rbp
   1e301:	ret
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e302:	lea    -0x12981(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1e309:	lea    0x48060(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1e310:	mov    $0x2b,%esi
   1e315:	call   *0x4a6fd(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e31b:	lea    0x480c6(%rip),%rcx        # 663e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e322:	mov    %r15,%rdi
   1e325:	mov    %r12,%rsi
   1e328:	mov    %r9,%rdx
   1e32b:	call   *0x4a68f(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e331:	lea    0x480c8(%rip),%rcx        # 66400 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x648>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e338:	mov    %r15,%rdi
   1e33b:	mov    %rbx,%rsi
   1e33e:	mov    %r9,%rdx
   1e341:	call   *0x4a679(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e347:	lea    -0x129c6(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1e34e:	lea    0x4804b(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1e355:	mov    $0x2b,%esi
   1e35a:	call   *0x4a6b8(%rip)        # 68a18 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e360:	lea    0x48021(%rip),%rcx        # 66388 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5d0>
   1e367:	mov    %r12,%rdi
   1e36a:	mov    %r15,%rsi
   1e36d:	mov    %r9,%rdx
   1e370:	call   *0x4a64a(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e376:	lea    0x47fdb(%rip),%rcx        # 66358 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e37d:	mov    %r15,%rdi
   1e380:	mov    %r9,%rdx
   1e383:	call   *0x4a637(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e389:	lea    -0x12a08(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1e390:	lea    0x48039(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1e397:	mov    $0x2b,%esi
   1e39c:	call   *0x4a676(%rip)        # 68a18 <_DYNAMIC+0x468>
   1e3a2:	lea    -0x12a21(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1e3a9:	lea    0x48008(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1e3b0:	mov    $0x2b,%esi
   1e3b5:	call   *0x4a65d(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e3bb:	mov    $0x1,%ecx
   1e3c0:	mov    %rcx,0x8(%rsp)
   1e3c5:	jmp    1e3ca <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x58a>
   1e3c7:	mov    %rax,%rbp
   1e3ca:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e3cf:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e3d4:	mov    %rbp,0x28(%rsp)
   1e3d9:	mov    %rax,0x30(%rsp)
   1e3de:	lea    0x47f8b(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1e3e5:	lea    0x20(%rsp),%rdi
   1e3ea:	mov    %r9,%rsi
   1e3ed:	call   *0x4a62d(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e3f3:	mov    $0x1,%ecx
   1e3f8:	mov    %rcx,0x8(%rsp)
   1e3fd:	jmp    1e402 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5c2>
   1e3ff:	mov    %rax,%rsi
   1e402:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e407:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e40c:	mov    %rsi,0x28(%rsp)
   1e411:	mov    %rax,0x30(%rsp)
   1e416:	lea    0x47f83(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1e41d:	lea    0x20(%rsp),%rdi
   1e422:	mov    (%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e426:	call   *0x4a5f4(%rip)        # 68a20 <_DYNAMIC+0x470>
   1e42c:	mov    $0x1,%ecx
   1e431:	mov    %rcx,0x8(%rsp)
   1e436:	jmp    1e43b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5fb>
   1e438:	mov    %rax,%rsi
   1e43b:	mov    0x8(%rsp),%rcx
   1e440:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e445:	mov    %rsi,0x28(%rsp)
   1e44a:	mov    %rax,0x30(%rsp)
   1e44f:	lea    0x47f62(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1e456:	lea    0x20(%rsp),%rdi
   1e45b:	mov    (%rsp),%rsi
   1e45f:	call   *0x4a5bb(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e465:	mov    $0x1,%ecx
   1e46a:	mov    %rcx,0x8(%rsp)
   1e46f:	jmp    1e474 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x634>
   1e471:	mov    %rax,%rsi
   1e474:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e479:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e47e:	mov    %rsi,0x28(%rsp)
   1e483:	mov    %rax,0x30(%rsp)
   1e488:	lea    0x47f41(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1e48f:	lea    0x20(%rsp),%rdi
   1e494:	mov    (%rsp),%rsi
   1e498:	call   *0x4a582(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e49e:	int3
   1e49f:	int3

000000000001e4a0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>>:
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:372
   1e4a0:	push   %rbp
   1e4a1:	push   %r15
   1e4a3:	push   %r14
   1e4a5:	push   %r13
   1e4a7:	push   %r12
   1e4a9:	push   %rbx
   1e4aa:	sub    $0x98,%rsp
   1e4b1:	mov    %rdx,%r12
   1e4b4:	mov    %rsi,0x20(%rsp)
   1e4b9:	mov    0xe0(%rsp),%rax
   1e4c1:	mov    %rcx,0x78(%rsp)
   1e4c6:	mov    %r8,0x80(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:380
   1e4ce:	mov    %r9,%rbx
   1e4d1:	sub    %rdx,%rbx
   1e4d4:	mov    (%rdi),%rcx
   1e4d7:	mov    %rcx,0x70(%rsp)
   1e4dc:	mov    0x8(%rdi),%rsi
   1e4e0:	mov    %r9,0x88(%rsp)
   1e4e8:	lea    0x2b(%r9),%rcx
   1e4ec:	mov    %rcx,0x90(%rsp)
   1e4f4:	mov    0x18(%rdi),%rcx
   1e4f8:	mov    %rcx,0x40(%rsp)
   1e4fd:	mov    %rdi,0x68(%rsp)
   1e502:	mov    0x10(%rdi),%r11
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e506:	mov    0x8(%rax),%r13
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e50a:	movq   $0x0,0x18(%rsp)
   1e513:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e516:	mov    0x78(%rsp),%rcx
   1e51b:	mov    0x80(%rsp),%r8
   1e523:	mov    %r15,0x10(%rsp)
   1e528:	mov    0x70(%rsp),%r14
   1e52d:	jmp    1e58d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xed>
   1e52f:	mov    0x30(%rsp),%r11
   1e534:	add    $0x2,%r11
   1e538:	mov    0x28(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e53d:	dec    %rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e540:	inc    %r14
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e543:	mov    0x68(%rsp),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:359
   1e548:	mov    %r14,(%rax)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:359
   1e54b:	mov    %rsi,0x8(%rax)
   1e54f:	mov    0x40(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e554:	dec    %rdx
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:360
   1e557:	mov    %r11,0x10(%rax)
   1e55b:	mov    %rdx,0x40(%rsp)
   1e560:	mov    %rdx,0x18(%rax)
   1e564:	mov    %r12,%rbx
   1e567:	add    0x10(%rsp),%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:386
   1e56c:	sub    %rdi,%rbx
   1e56f:	add    %r9,%rbx
   1e572:	mov    0x38(%rsp),%r12
   1e577:	nopw   0x0(%rax,%rax,1)
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e580:	add    %r9,0x20(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e585:	sub    %r9,%r12
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e588:	mov    %rdi,0x10(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1e58d:	mov    0xe0(%rsp),%rax
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1e595:	mov    0x10(%rax),%rbp
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e599:	cmp    $0x2,%rsi
first_chunk<u8, 2>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e59d:	jae    1e5b0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x110>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e59f:	test   %rsi,%rsi
split_first<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e5a2:	jne    1e7d0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x330>
   1e5a8:	jmp    1ee5b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x9bb>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e5ad:	nopl   (%rax)
   1e5b0:	mov    0x88(%rsp),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e5b8:	cmp    %rax,%rbp
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e5bb:	cmovb  %rbp,%rax
   1e5bf:	cmp    $0x1e,%r12
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:335
   1e5c3:	jb     1e7d0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x330>
   1e5c9:	mov    0x90(%rsp),%rdx
   1e5d1:	sub    %rbx,%rdx
   1e5d4:	cmp    %rax,%rdx
   1e5d7:	ja     1e7d0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x330>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e5dd:	cmpq   $0x1,0x40(%rsp)
split_at_checked<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e5e3:	jbe    1ef50 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xab0>
batch():
   1e5e9:	mov    %r12,%r15
   1e5ec:	movzwl (%r14),%r10d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:338
   1e5f0:	movzwl (%r11),%edx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:340
   1e5f4:	mov    %r10d,%r9d
   1e5f7:	shr    $0x4,%r9d
   1e5fb:	and    $0xf,%r9d
   1e5ff:	mov    %rbx,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:343
   1e602:	cmp    $0xf,%r9d
   1e606:	je     1e7ea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x34a>
   1e60c:	mov    %r10d,%edi
   1e60f:	and    $0xf,%edi
   1e612:	add    $0x5,%rdi
   1e616:	cmp    $0x14,%edi
   1e619:	je     1e7ea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x34a>
   1e61f:	movzwl %dx,%ebx
   1e622:	mov    0x10(%rsp),%rax
   1e627:	add    %r9,%rax
   1e62a:	cmp    %rbx,%rax
   1e62d:	jbe    1e7ea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x34a>
   1e633:	inc    %rbx
   1e636:	cmp    %edi,%ebx
   1e638:	jb     1e7ea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x34a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e63e:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e641:	sub    0x10(%rsp),%rdx
   1e646:	jb     1ef5d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xabd>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e64c:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e650:	jbe    1ef75 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xad5>
batch():
   1e656:	mov    %r15,0x38(%rsp)
   1e65b:	mov    %rsi,0x28(%rsp)
   1e660:	mov    %r11,0x30(%rsp)
   1e665:	movzwl 0x2(%r11),%r11d
   1e66a:	mov    0x20(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e66f:	movups (%rdx),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e672:	mov    0x10(%rsp),%rdx
   1e677:	movups %xmm0,0x0(%r13,%rdx,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:349
   1e67d:	mov    %rax,%rsi
   1e680:	sub    %rbx,%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e683:	mov    %rbp,%rdx
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e686:	sub    %rsi,%rdx
   1e689:	jb     1ef89 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xae9>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e68f:	cmp    $0x18,%rdx
first_chunk<u8, 24>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e693:	jb     1ef9f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xaff>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e699:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e69c:	sub    %rax,%rdx
   1e69f:	jb     1efac <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb0c>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e6a5:	cmp    $0x17,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e6a9:	jbe    1efc2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb22>
batch():
   1e6af:	add    %r13,%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e6b2:	movups (%rsi),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e6b5:	mov    0x10(%rsi),%rdx
   1e6b9:	mov    %rdx,0x10(%r13,%rax,1)
   1e6be:	movups %xmm0,0x0(%r13,%rax,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:351
   1e6c4:	add    %rax,%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:353
   1e6c7:	mov    %r10d,%esi
   1e6ca:	shr    $0xc,%esi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:356
   1e6cd:	cmp    $0xf,%esi
   1e6d0:	je     1e52f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8f>
   1e6d6:	shr    $0x8,%r10d
   1e6da:	and    $0xf,%r10d
   1e6de:	add    $0x5,%r10
   1e6e2:	cmp    $0x14,%r10d
   1e6e6:	je     1e52f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8f>
   1e6ec:	lea    (%rdi,%rsi,1),%rax
   1e6f0:	cmp    %r11,%rax
   1e6f3:	jbe    1e52f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8f>
   1e6f9:	inc    %r11
   1e6fc:	cmp    %r10d,%r11d
   1e6ff:	jb     1e52f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8f>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e705:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e708:	sub    %rdi,%rdx
   1e70b:	jb     1efeb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb4b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e711:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e715:	jbe    1effe <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb5e>
batch():
   1e71b:	mov    0x20(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e720:	movups (%rdx,%r9,1),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e725:	movups %xmm0,0x0(%r13,%rdi,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:364
   1e72b:	mov    %rax,%rdi
   1e72e:	sub    %r11,%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e731:	mov    %rbp,%rdx
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e734:	sub    %rdi,%rdx
   1e737:	jb     1f012 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb72>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e73d:	cmp    $0x18,%rdx
first_chunk<u8, 24>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e741:	jb     1f025 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb85>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e747:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e74a:	sub    %rax,%rdx
   1e74d:	jb     1f032 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb92>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e753:	cmp    $0x17,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e757:	jbe    1f048 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xba8>
batch():
   1e75d:	mov    %r12,%rbx
   1e760:	mov    0x30(%rsp),%r12
   1e765:	add    $0x4,%r12
   1e769:	mov    0x40(%rsp),%r11
   1e76e:	add    $0xfffffffffffffffe,%r11
   1e772:	add    %r13,%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e775:	movups (%rdi),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e778:	mov    0x10(%rdi),%rdx
   1e77c:	mov    %rdx,0x10(%r13,%rax,1)
   1e781:	movups %xmm0,0x0(%r13,%rax,1)
   1e787:	mov    0x28(%rsp),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e78c:	add    $0xfffffffffffffffe,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e790:	add    $0x2,%r14
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e794:	mov    0x68(%rsp),%rdx
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:366
   1e799:	mov    %r14,(%rdx)
   1e79c:	mov    %rdi,0x8(%rdx)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:367
   1e7a0:	mov    %r12,0x10(%rdx)
   1e7a4:	mov    %r11,0x40(%rsp)
   1e7a9:	mov    %r11,0x18(%rdx)
   1e7ad:	mov    %r12,%r11
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:368
   1e7b0:	add    %rsi,%r9
   1e7b3:	mov    %rdi,%rsi
   1e7b6:	add    %rax,%r10
   1e7b9:	mov    %r10,%rdi
   1e7bc:	jmp    1e567 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc7>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e7c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
split_first<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e7d0:	cmpq   $0x0,0x40(%rsp)
   1e7d6:	je     1eee7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa47>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e7dc:	mov    %r12,%r15
next():
   1e7df:	mov    %rbx,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:321
   1e7e2:	movzbl (%r14),%r10d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:322
   1e7e6:	movzwl (%r11),%edx
   1e7ea:	mov    %rbp,0x8(%rsp)
split_first<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e7ef:	dec    %rsi
   1e7f2:	inc    %r14
split_first<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e7f5:	add    $0x2,%r11
   1e7f9:	mov    0x40(%rsp),%rdi
   1e7fe:	dec    %rdi
   1e801:	mov    0x68(%rsp),%rax
   1e806:	mov    %r14,0x70(%rsp)
next():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:323
   1e80b:	mov    %r14,(%rax)
   1e80e:	mov    %rsi,0x28(%rsp)
   1e813:	mov    %rsi,0x8(%rax)
   1e817:	mov    %r11,0x30(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:324
   1e81c:	mov    %r11,0x10(%rax)
   1e820:	mov    %rdi,0x40(%rsp)
   1e825:	mov    %rdi,0x18(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:325
   1e829:	mov    %r10d,%eax
   1e82c:	shr    $0x4,%al
   1e82f:	and    $0xf,%r10b
   1e833:	mov    %edx,%esi
   1e835:	shl    $0x10,%esi
   1e838:	movzbl %r10b,%r14d
   1e83c:	shl    $0x8,%r14d
   1e840:	or     %esi,%r14d
   1e843:	movzbl %al,%eax
   1e846:	lea    (%r14,%rax,1),%ebx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:389
   1e84a:	shr    $0x8,%r14d
   1e84e:	movzwl %dx,%ebp
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:395
   1e851:	cmp    $0xf,%al
   1e853:	je     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e859:	cmp    $0xf,%r14b
   1e85d:	jne    1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e863:	test   %r8,%r8
   1e866:	je     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:397
   1e86c:	movzbl (%rcx),%edx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:399
   1e86f:	lea    0x14(%rdx),%rdi
   1e873:	mov    %r12,%rax
   1e876:	sub    %rdi,%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:403
   1e879:	jb     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e87f:	mov    %ebx,%r9d
   1e882:	and    $0xf,%r9d
   1e886:	mov    0x10(%rsp),%rsi
   1e88b:	add    %r9,%rsi
   1e88e:	lea    0x1(%rbp),%r11d
   1e892:	mov    %rsi,%r10
   1e895:	sub    %r11,%r10
   1e898:	jb     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e89e:	cmp    $0x2c,%dl
   1e8a1:	ja     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e8a7:	cmp    %r11d,%edi
   1e8aa:	ja     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:407
   1e8b0:	lea    0x40(%rsi),%rdx
   1e8b4:	cmp    0x8(%rsp),%rdx
   1e8b9:	ja     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e8bf:	cmp    $0x10,%r15
   1e8c3:	jb     1e980 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4e0>
   1e8c9:	mov    0x8(%rsp),%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e8ce:	mov    %rbx,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e8d1:	mov    0x10(%rsp),%r11
   1e8d6:	sub    %r11,%rdx
   1e8d9:	jb     1eef4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa54>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e8df:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e8e3:	jbe    1ef0a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa6a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e8e9:	mov    0x20(%rsp),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e8ee:	movups (%rdx),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e8f1:	movups %xmm0,0x0(%r13,%r11,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:411
   1e8f7:	lea    0x40(%r10),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e8fb:	cmp    %rdx,%rbx
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e8fe:	jb     1f11b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc7b>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e904:	cmp    $0xffffffffffffffc0,%r10
   1e908:	mov    0x70(%rsp),%r14
   1e90d:	mov    0x30(%rsp),%r11
   1e912:	jae    1f10f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc6f>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e918:	add    $0xffffffffffffffc0,%rbx
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e91c:	cmp    %rbx,%rsi
   1e91f:	ja     1ef1e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa7e>
   1e925:	mov    %r15,%r12
   1e928:	inc    %rcx
   1e92b:	dec    %r8
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e92e:	movups 0x0(%r13,%r10,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e934:	movups 0x10(%r13,%r10,1),%xmm1
   1e93a:	movups 0x20(%r13,%r10,1),%xmm2
   1e940:	movups 0x30(%r13,%r10,1),%xmm3
   1e946:	movups %xmm3,0x30(%r13,%rsi,1)
   1e94c:	movups %xmm2,0x20(%r13,%rsi,1)
   1e952:	movups %xmm1,0x10(%r13,%rsi,1)
   1e958:	movups %xmm0,0x0(%r13,%rsi,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:412
   1e95e:	add    %rsi,%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:414
   1e961:	mov    %rcx,0x78(%rsp)
   1e966:	mov    %r8,0x80(%rsp)
   1e96e:	mov    %rax,%rbx
   1e971:	mov    0x28(%rsp),%rsi
   1e976:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe0>
   1e97b:	nopl   0x0(%rax,%rax,1)
from():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1e980:	and    $0xf,%ebx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:420
   1e983:	cmp    $0xf,%rbx
   1e987:	jne    1e9a2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x502>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1e989:	lea    0x78(%rsp),%rdi
   1e98e:	call   20190 <zxc_codec::block::extra>
   1e993:	mov    %rdx,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e996:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e998:	jne    1eecd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa2d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1e99e:	add    $0xf,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1e9a2:	movzbl %r14b,%r14d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:423
   1e9a6:	add    $0x5,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:424
   1e9aa:	cmp    $0x14,%r14
   1e9ae:	jne    1e9c9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x529>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1e9b0:	lea    0x78(%rsp),%rdi
   1e9b5:	call   20190 <zxc_codec::block::extra>
   1e9ba:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e9bd:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e9bf:	jne    1eea9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa09>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1e9c5:	add    $0x14,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:428
   1e9c9:	sub    %r14,%r12
   1e9cc:	mov    0x88(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:74
   1e9d4:	jb     1ee8d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x9ed>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:432
   1e9da:	mov    %rcx,%rax
   1e9dd:	mov    %r12,0x60(%rsp)
   1e9e2:	sub    %r12,%rax
   1e9e5:	mov    0x8(%rsp),%rsi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:433
   1e9ea:	cmp    %rsi,%rax
   1e9ed:	jbe    1ea60 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5c0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:434
   1e9ef:	lea    (%rsi,%rsi,1),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1e9f3:	cmp    %rdx,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1e9f6:	cmova  %rax,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e9fa:	cmp    %rcx,%rdx
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e9fd:	cmovae %rcx,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1ea01:	cmp    %rsi,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1ea04:	mov    0x30(%rsp),%r11
   1ea09:	mov    %r15,%r12
   1ea0c:	jbe    1ea6a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5ca>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1ea0e:	sub    %rsi,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1ea11:	mov    0xe0(%rsp),%rax
capacity<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1ea19:	mov    (%rax),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1ea1c:	sub    %rsi,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1ea1f:	cmp    %rax,%rdx
needs_to_grow<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1ea22:	mov    %rdx,0x38(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1ea27:	ja     1ee28 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x988>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ea2d:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ea35:	mov    0x8(%rax),%r13
   1ea39:	mov    0x8(%rsp),%r15
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1ea3e:	lea    (%r15,%r13,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ea42:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ea44:	call   *0x49fb6(%rip)        # 68a00 <memset@GLIBC_2.2.5>
   1ea4a:	mov    0x38(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1ea4f:	add    %r15,%rdx
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1ea52:	mov    0x30(%rsp),%r11
   1ea57:	jmp    1ea6f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5cf>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ea59:	nopl   0x0(%rax)
   1ea60:	mov    0x30(%rsp),%r11
   1ea65:	mov    %r15,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:433
   1ea68:	jmp    1ea80 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5e0>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1ea6a:	cmp    %rsi,%rdx
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1ea6d:	jae    1ea80 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5e0>
resize<u8, alloc::alloc::Global>():
   1ea6f:	mov    0xe0(%rsp),%rax
   1ea77:	mov    %rdx,0x10(%rax)
   1ea7b:	mov    %rdx,0x8(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ea80:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:436
   1ea85:	lea    (%rbx,%rax,1),%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:442
   1ea89:	cmp    $0x20,%rbx
   1ea8d:	ja     1ead0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x630>
   1ea8f:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:443
   1ea94:	lea    0x20(%rax),%rsi
   1ea98:	cmp    0x8(%rsp),%rsi
   1ea9d:	ja     1eaa9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x609>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1ea9f:	cmp    $0x20,%r12
first_chunk<u8, 32>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eaa3:	jae    1ecc4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x824>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1eaa9:	cmp    $0x9,%rbx
   1eaad:	jae    1ead0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x630>
   1eaaf:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:449
   1eab4:	lea    0x8(%rax),%rsi
   1eab8:	cmp    0x8(%rsp),%rsi
   1eabd:	ja     1eac9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x629>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eabf:	cmp    $0x8,%r12
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eac3:	jae    1edf0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x950>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:454
   1eac9:	test   %rbx,%rbx
   1eacc:	je     1eb27 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x687>
   1eace:	xchg   %ax,%ax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1ead0:	sub    %rbx,%r12
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1ead3:	jb     1ee9b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x9fb>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ead9:	mov    0x10(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eade:	cmp    %rdi,%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eae1:	jb     1efd6 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb36>
   1eae7:	cmp    0x8(%rsp),%r15
   1eaec:	ja     1efd6 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb36>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eaf2:	mov    %r12,0x38(%rsp)
   1eaf7:	mov    0x20(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1eafc:	lea    (%rsi,%rbx,1),%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eb00:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eb08:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1eb0c:	add    %r13,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eb0f:	mov    %rbx,%rdx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eb12:	call   *0x49d68(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1eb18:	mov    0x30(%rsp),%r11
   1eb1d:	mov    %r12,0x20(%rsp)
   1eb22:	mov    0x38(%rsp),%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eb27:	inc    %ebp
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:459
   1eb29:	mov    %r15,%rsi
   1eb2c:	sub    %rbp,%rsi
   1eb2f:	mov    0x60(%rsp),%rbx
   1eb34:	jb     1ebb0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x710>
   1eb36:	cmp    %rbp,%r14
   1eb39:	ja     1ebb0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x710>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:465
   1eb3b:	cmp    $0x19,%r14
   1eb3f:	mov    0x8(%rsp),%rcx
   1eb44:	jae    1eda0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x900>
   1eb4a:	lea    0x18(%r15),%rax
   1eb4e:	cmp    %rcx,%rax
   1eb51:	jbe    1ed07 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x867>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1eb57:	cmp    $0x9,%r14
   1eb5b:	jae    1ed49 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8a9>
   1eb61:	lea    0x8(%r15),%rax
   1eb65:	cmp    %rcx,%rax
   1eb68:	ja     1ed4f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8af>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:468
   1eb6e:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1eb72:	cmp    %rax,%rcx
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1eb75:	jb     1f23d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd9d>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1eb7b:	cmp    $0xfffffffffffffff8,%rsi
   1eb7f:	jae    1f231 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd91>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1eb85:	add    $0xfffffffffffffff8,%rcx
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1eb89:	cmp    %rcx,%r15
   1eb8c:	ja     1f0f6 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc56>
   1eb92:	mov    0xe0(%rsp),%rax
   1eb9a:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1eb9e:	mov    0x0(%r13,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1eba3:	mov    %rax,0x0(%r13,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:474
   1eba8:	jmp    1ede3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x943>
   1ebad:	nopl   (%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:477
   1ebb0:	cmp    %rbp,%r15
   1ebb3:	jae    1ec24 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x784>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:480
   1ebb5:	mov    %rbp,%rbx
   1ebb8:	sub    %r15,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ebbb:	mov    0xd8(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ebc3:	sub    %rbx,%rsi
   1ebc6:	jb     1eeb3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa13>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ebcc:	cmp    %rbx,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ebcf:	cmovb  %r14,%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:486
   1ebd3:	lea    (%rbx,%r15,1),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1ebd7:	cmp    0x8(%rsp),%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1ebdc:	ja     1f088 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbe8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ebe2:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ebea:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ebee:	add    %r13,%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ebf1:	add    0xd0(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ebf9:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ebfc:	mov    %rdx,%r15
   1ebff:	mov    %rbx,%rdx
   1ec02:	call   *0x49c78(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1ec08:	mov    %r15,%rcx
   1ec0b:	mov    0x30(%rsp),%r11
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:489
   1ec10:	sub    %rbx,%r14
   1ec13:	mov    0x28(%rsp),%rsi
   1ec18:	mov    0x60(%rsp),%rbx
   1ec1d:	jne    1ec41 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x7a1>
   1ec1f:	jmp    1e516 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x76>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1ec24:	test   %r14,%r14
   1ec27:	mov    0x28(%rsp),%rsi
   1ec2c:	je     1e516 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x76>
   1ec32:	mov    0xe0(%rsp),%rax
   1ec3a:	mov    0x8(%rax),%r13
   1ec3e:	mov    %r15,%rcx
   1ec41:	mov    %r12,0x38(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:493
   1ec46:	mov    %rcx,%r12
   1ec49:	sub    %rbp,%r12
   1ec4c:	mov    %rcx,%r15
   1ec4f:	mov    0x8(%rsp),%rbp
   1ec54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:496
   1ec60:	mov    %r15,%rbx
   1ec63:	sub    %r12,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ec66:	cmp    %rbx,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ec69:	cmovb  %r14,%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:497
   1ec6d:	lea    (%rbx,%r12,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ec71:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ec74:	jb     1f155 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcb5>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ec7a:	cmp    %rax,%r12
   1ec7d:	ja     1f149 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xca9>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ec83:	mov    %rbp,%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ec86:	sub    %rbx,%rax
   1ec89:	cmp    %rax,%r15
   1ec8c:	ja     1ef37 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa97>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1ec92:	lea    (%r15,%r13,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ec96:	lea    (%r12,%r13,1),%rsi
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ec9a:	mov    %rbx,%rdx
   1ec9d:	call   *0x49d65(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1eca3:	mov    0x30(%rsp),%r11
   1eca8:	mov    0x28(%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:498
   1ecad:	add    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1ecb0:	sub    %rbx,%r14
   1ecb3:	jne    1ec60 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x7c0>
   1ecb5:	mov    0x38(%rsp),%r12
   1ecba:	mov    0x60(%rsp),%rbx
   1ecbf:	jmp    1e516 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x76>
   1ecc4:	mov    0x10(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ecc9:	cmp    $0xffffffffffffffe0,%rdi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eccd:	jae    1f0a0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc00>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ecd3:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ecdb:	mov    0x8(%rax),%r13
   1ecdf:	mov    0x20(%rsp),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ece4:	movups (%rax),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ece7:	movups 0x10(%rax),%xmm1
   1eceb:	movups %xmm1,0x10(%r13,%rdi,1)
   1ecf1:	movups %xmm0,0x0(%r13,%rdi,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1ecf7:	sub    %rbx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ecfa:	add    %rbx,%rax
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ecfd:	mov    %rax,0x20(%rsp)
   1ed02:	jmp    1eb27 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x687>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:466
   1ed07:	lea    0x18(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed0b:	cmp    %rax,%rcx
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed0e:	jb     1f1c9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd29>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ed14:	cmp    $0xffffffffffffffe8,%rsi
   1ed18:	jae    1f1bd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd1d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed1e:	add    $0xffffffffffffffe8,%rcx
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed22:	cmp    %rcx,%r15
   1ed25:	ja     1f0b2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc12>
   1ed2b:	mov    0xe0(%rsp),%rax
   1ed33:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed37:	movups 0x0(%r13,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed3d:	mov    0x10(%r13,%rsi,1),%rax
   1ed42:	mov    %rax,0x10(%r13,%r15,1)
   1ed47:	jmp    1ed8e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8ee>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:469
   1ed49:	cmp    $0x10,%r14
   1ed4d:	ja     1eda0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x900>
   1ed4f:	lea    0x10(%r15),%rax
   1ed53:	cmp    %rcx,%rax
   1ed56:	ja     1eda0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x900>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:470
   1ed58:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed5c:	cmp    %rax,%rcx
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed5f:	jb     1f203 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd63>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ed65:	cmp    $0xfffffffffffffff0,%rsi
   1ed69:	jae    1f1f7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd57>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed6f:	add    $0xfffffffffffffff0,%rcx
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed73:	cmp    %rcx,%r15
   1ed76:	ja     1f0dd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc3d>
   1ed7c:	mov    0xe0(%rsp),%rax
   1ed84:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed88:	movups 0x0(%r13,%rsi,1),%xmm0
   1ed8e:	movups %xmm0,0x0(%r13,%r15,1)
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed94:	jmp    1ede3 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x943>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ed96:	cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:472
   1eda0:	lea    (%r14,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1eda4:	cmp    %rax,%rcx
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1eda7:	jb     1f18f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcef>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1edad:	cmp    %rax,%rsi
   1edb0:	ja     1f183 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xce3>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1edb6:	sub    %r14,%rcx
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1edb9:	cmp    %rcx,%r15
   1edbc:	ja     1f06f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbcf>
   1edc2:	mov    0xe0(%rsp),%rax
   1edca:	mov    0x8(%rax),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1edce:	add    %r13,%rsi
   1edd1:	lea    (%r15,%r13,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1edd5:	mov    %r14,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1edd8:	call   *0x49c2a(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1edde:	mov    0x30(%rsp),%r11
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:474
   1ede3:	add    %r14,%r15
   1ede6:	mov    0x28(%rsp),%rsi
   1edeb:	jmp    1e516 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x76>
   1edf0:	mov    0x10(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1edf5:	cmp    $0xfffffffffffffff8,%rdi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1edf9:	jae    1f0cb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc2b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1edff:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ee07:	mov    0x8(%rax),%r13
   1ee0b:	mov    0x20(%rsp),%rcx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ee10:	mov    (%rcx),%rax
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ee13:	mov    %rax,0x0(%r13,%rdi,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1ee18:	sub    %rbx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ee1b:	add    %rbx,%rcx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ee1e:	mov    %rcx,0x20(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1ee23:	jmp    1eb27 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x687>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1ee28:	mov    $0x1,%ecx
   1ee2d:	mov    $0x1,%r8d
   1ee33:	mov    0xe0(%rsp),%r13
   1ee3b:	mov    %r13,%rdi
   1ee3e:	mov    0x8(%rsp),%rsi
   1ee43:	call   26430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
   1ee48:	mov    0x38(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1ee4d:	mov    0x10(%r13),%rax
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1ee51:	mov    %rax,0x8(%rsp)
   1ee56:	jmp    1ea2d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x58d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ee5b:	mov    0x10(%rsp),%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:502
   1ee60:	mov    %rdi,%rbx
   1ee63:	add    %r12,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ee66:	jb     1f05c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbbc>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ee6c:	cmp    %rbp,%rbx
   1ee6f:	ja     1f05c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbbc>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ee75:	add    %rdi,%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ee78:	mov    %r13,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ee7b:	mov    0x20(%rsp),%rsi
   1ee80:	mov    %r12,%rdx
   1ee83:	call   *0x499f7(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1ee89:	xor    %eax,%eax
   1ee8b:	jmp    1eed2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa32>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1ee8d:	lea    -0x134f7(%rip),%rsi        # b99d <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1ee94:	mov    $0x18,%edx
   1ee99:	jmp    1eebf <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa1f>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1ee9b:	lea    -0x11fbb(%rip),%rsi        # cee7 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.1069639741503911768>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1eea2:	mov    $0xd,%edx
   1eea7:	jmp    1eebf <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa1f>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eea9:	mov    $0x1,%eax
   1eeae:	mov    %r14,%rbx
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1eeb1:	jmp    1eed2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa32>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1eeb3:	lea    -0x13505(%rip),%rsi        # b9b5 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1eeba:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eebf:	mov    $0x15,%edi
   1eec4:	call   *0x49b46(%rip)        # 68a10 <_DYNAMIC+0x460>
   1eeca:	mov    %rax,%rbx
   1eecd:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:504
   1eed2:	mov    %rbx,%rdx
   1eed5:	add    $0x98,%rsp
   1eedc:	pop    %rbx
   1eedd:	pop    %r12
   1eedf:	pop    %r13
   1eee1:	pop    %r14
   1eee3:	pop    %r15
   1eee5:	pop    %rbp
   1eee6:	ret
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1eee7:	lea    0x47602(%rip),%rdi        # 664f0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x738>
unwrap<(&[u8; 2], &[[u8; 2]])>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1eeee:	call   *0x4997c(%rip)        # 68870 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1eef4:	lea    0x4754d(%rip),%rcx        # 66448 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x690>
   1eefb:	mov    %r11,%rdi
   1eefe:	mov    %rbx,%rsi
   1ef01:	mov    %rbx,%rdx
   1ef04:	call   *0x49ab6(%rip)        # 689c0 <_DYNAMIC+0x410>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1ef0a:	lea    0x47507(%rip),%rcx        # 66418 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x660>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ef11:	mov    $0x10,%esi
   1ef16:	xor    %edi,%edi
   1ef18:	call   *0x49aa2(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ef1e:	lea    -0x1359d(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1ef25:	lea    0x47504(%rip),%rdx        # 66430 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x678>
   1ef2c:	mov    $0x2b,%esi
   1ef31:	call   *0x49ae1(%rip)        # 68a18 <_DYNAMIC+0x468>
   1ef37:	lea    -0x135b6(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1ef3e:	lea    0x4742b(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1ef45:	mov    $0x2b,%esi
   1ef4a:	call   *0x49ac8(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1ef50:	lea    0x475b1(%rip),%rdi        # 66508 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x750>
unwrap<(&[[u8; 2]; 2], &[[u8; 2]])>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1ef57:	call   *0x49913(%rip)        # 68870 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1ef5d:	lea    0x476c4(%rip),%rcx        # 66628 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x870>
   1ef64:	mov    0x10(%rsp),%rdi
batch():
   1ef69:	mov    %rbp,%rsi
   1ef6c:	mov    %rbp,%rdx
   1ef6f:	call   *0x49a4b(%rip)        # 689c0 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1ef75:	lea    0x475a4(%rip),%rcx        # 66520 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x768>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ef7c:	mov    $0x10,%esi
   1ef81:	xor    %edi,%edi
   1ef83:	call   *0x49a37(%rip)        # 689c0 <_DYNAMIC+0x410>
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:545
   1ef89:	lea    0x47680(%rip),%rcx        # 66610 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x858>
   1ef90:	mov    %rsi,%rdi
batch():
   1ef93:	mov    %rbp,%rsi
   1ef96:	mov    %rbp,%rdx
   1ef99:	call   *0x49a21(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1ef9f:	lea    0x47652(%rip),%rdi        # 665f8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x840>
unwrap<&[u8; 24]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1efa6:	call   *0x498c4(%rip)        # 68870 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1efac:	lea    0x4762d(%rip),%rcx        # 665e0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x828>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1efb3:	mov    %rax,%rdi
batch():
   1efb6:	mov    %rbp,%rsi
   1efb9:	mov    %rbp,%rdx
   1efbc:	call   *0x499fe(%rip)        # 689c0 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1efc2:	lea    0x4756f(%rip),%rcx        # 66538 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x780>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1efc9:	mov    $0x18,%esi
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1efce:	xor    %edi,%edi
   1efd0:	call   *0x499ea(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1efd6:	lea    0x4740b(%rip),%rcx        # 663e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1efdd:	mov    %r15,%rsi
   1efe0:	mov    0x8(%rsp),%rdx
   1efe5:	call   *0x499d5(%rip)        # 689c0 <_DYNAMIC+0x410>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1efeb:	lea    0x475d6(%rip),%rcx        # 665c8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x810>
batch():
   1eff2:	mov    %rbp,%rsi
   1eff5:	mov    %rbp,%rdx
   1eff8:	call   *0x499c2(%rip)        # 689c0 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1effe:	lea    0x4754b(%rip),%rcx        # 66550 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x798>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f005:	mov    $0x10,%esi
   1f00a:	xor    %edi,%edi
   1f00c:	call   *0x499ae(%rip)        # 689c0 <_DYNAMIC+0x410>
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:545
   1f012:	lea    0x47597(%rip),%rcx        # 665b0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x7f8>
batch():
   1f019:	mov    %rbp,%rsi
   1f01c:	mov    %rbp,%rdx
   1f01f:	call   *0x4999b(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f025:	lea    0x4756c(%rip),%rdi        # 66598 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x7e0>
unwrap<&[u8; 24]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f02c:	call   *0x4983e(%rip)        # 68870 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f032:	lea    0x47547(%rip),%rcx        # 66580 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x7c8>
   1f039:	mov    %rax,%rdi
batch():
   1f03c:	mov    %rbp,%rsi
   1f03f:	mov    %rbp,%rdx
   1f042:	call   *0x49978(%rip)        # 689c0 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f048:	lea    0x47519(%rip),%rcx        # 66568 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x7b0>
   1f04f:	mov    $0x18,%esi
   1f054:	xor    %edi,%edi
   1f056:	call   *0x49964(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f05c:	lea    0x4739d(%rip),%rcx        # 66400 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x648>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f063:	mov    %rbx,%rsi
   1f066:	mov    %rbp,%rdx
   1f069:	call   *0x49951(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f06f:	lea    -0x136ee(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f076:	lea    0x47323(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1f07d:	mov    $0x2b,%esi
   1f082:	call   *0x49990(%rip)        # 68a18 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f088:	lea    0x472f9(%rip),%rcx        # 66388 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5d0>
   1f08f:	mov    %r15,%rdi
   1f092:	mov    %rdx,%rsi
   1f095:	mov    0x8(%rsp),%rdx
   1f09a:	call   *0x49920(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0a0:	lea    0x473b9(%rip),%rcx        # 66460 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x6a8>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0a7:	mov    0x8(%rsp),%rdx
   1f0ac:	call   *0x4990e(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f0b2:	lea    -0x13731(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f0b9:	lea    0x473b8(%rip),%rdx        # 66478 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x6c0>
   1f0c0:	mov    $0x2b,%esi
   1f0c5:	call   *0x4994d(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0cb:	lea    0x47286(%rip),%rcx        # 66358 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0d2:	mov    0x8(%rsp),%rdx
   1f0d7:	call   *0x498e3(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f0dd:	lea    -0x1375c(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f0e4:	lea    0x472cd(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1f0eb:	mov    $0x2b,%esi
   1f0f0:	call   *0x49922(%rip)        # 68a18 <_DYNAMIC+0x468>
   1f0f6:	lea    -0x13775(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f0fd:	lea    0x472cc(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1f104:	mov    $0x2b,%esi
   1f109:	call   *0x49909(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f10f:	mov    $0x1,%eax
   1f114:	mov    %rax,0x18(%rsp)
   1f119:	jmp    1f11e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc7e>
   1f11b:	mov    %rdx,%r10
   1f11e:	mov    0x18(%rsp),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f123:	mov    %rax,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f128:	mov    %r10,0x50(%rsp)
   1f12d:	mov    %rdx,0x58(%rsp)
   1f132:	lea    0x472f7(%rip),%rdx        # 66430 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x678>
   1f139:	lea    0x48(%rsp),%rdi
   1f13e:	mov    0x8(%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f143:	call   *0x498d7(%rip)        # 68a20 <_DYNAMIC+0x470>
   1f149:	mov    $0x1,%ecx
   1f14e:	mov    %rcx,0x18(%rsp)
   1f153:	jmp    1f158 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcb8>
   1f155:	mov    %rax,%r12
   1f158:	mov    0x18(%rsp),%rcx
   1f15d:	mov    %rcx,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f162:	mov    %r12,0x50(%rsp)
   1f167:	mov    %rax,0x58(%rsp)
   1f16c:	lea    0x471fd(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1f173:	lea    0x48(%rsp),%rdi
   1f178:	mov    0x8(%rsp),%rsi
   1f17d:	call   *0x4989d(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f183:	mov    $0x1,%ecx
   1f188:	mov    %rcx,0x18(%rsp)
   1f18d:	jmp    1f192 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcf2>
   1f18f:	mov    %rax,%rsi
   1f192:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f197:	mov    %rcx,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f19c:	mov    %rsi,0x50(%rsp)
   1f1a1:	mov    %rax,0x58(%rsp)
   1f1a6:	lea    0x471f3(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1f1ad:	lea    0x48(%rsp),%rdi
   1f1b2:	mov    0x8(%rsp),%rsi
   1f1b7:	call   *0x49863(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f1bd:	mov    $0x1,%ecx
   1f1c2:	mov    %rcx,0x18(%rsp)
   1f1c7:	jmp    1f1cc <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd2c>
   1f1c9:	mov    %rax,%rsi
   1f1cc:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f1d1:	mov    %rcx,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f1d6:	mov    %rsi,0x50(%rsp)
   1f1db:	mov    %rax,0x58(%rsp)
   1f1e0:	lea    0x47291(%rip),%rdx        # 66478 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x6c0>
   1f1e7:	lea    0x48(%rsp),%rdi
   1f1ec:	mov    0x8(%rsp),%rsi
   1f1f1:	call   *0x49829(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f1f7:	mov    $0x1,%ecx
   1f1fc:	mov    %rcx,0x18(%rsp)
   1f201:	jmp    1f206 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd66>
   1f203:	mov    %rax,%rsi
   1f206:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f20b:	mov    %rcx,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f210:	mov    %rsi,0x50(%rsp)
   1f215:	mov    %rax,0x58(%rsp)
   1f21a:	lea    0x47197(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1f221:	lea    0x48(%rsp),%rdi
   1f226:	mov    0x8(%rsp),%rsi
   1f22b:	call   *0x497ef(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f231:	mov    $0x1,%ecx
   1f236:	mov    %rcx,0x18(%rsp)
   1f23b:	jmp    1f240 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xda0>
   1f23d:	mov    %rax,%rsi
   1f240:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f245:	mov    %rcx,0x48(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f24a:	mov    %rsi,0x50(%rsp)
   1f24f:	mov    %rax,0x58(%rsp)
   1f254:	lea    0x47175(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1f25b:	lea    0x48(%rsp),%rdi
   1f260:	mov    0x8(%rsp),%rsi
   1f265:	call   *0x497b5(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f26b:	int3
   1f26c:	int3
   1f26d:	int3
   1f26e:	int3
   1f26f:	int3

000000000001f270 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>>:
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:372
   1f270:	push   %rbp
   1f271:	push   %r15
   1f273:	push   %r14
   1f275:	push   %r13
   1f277:	push   %r12
   1f279:	push   %rbx
   1f27a:	sub    $0x68,%rsp
   1f27e:	mov    %rcx,%rbp
   1f281:	mov    %rdx,0x20(%rsp)
   1f286:	mov    0xb8(%rsp),%r13
   1f28e:	mov    %r8,0x58(%rsp)
   1f293:	mov    %r9,0x60(%rsp)
   1f298:	mov    %rsi,0x48(%rsp)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/non_null.rs:1709
   1f29d:	cmp    %rsi,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/iter/macros.rs:180
   1f2a0:	je     1f69b <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x42b>
   1f2a6:	mov    %rdi,%r12
   1f2a9:	mov    0xa0(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:380
   1f2b1:	sub    %rbp,%rax
   1f2b4:	mov    %rax,0x40(%rsp)
   1f2b9:	movq   $0x0,0x10(%rsp)
   1f2c2:	xor    %r15d,%r15d
   1f2c5:	jmp    1f2f6 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x86>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f2c7:	movups (%rdi,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f2cb:	movups %xmm0,(%rdi,%rbx,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:474
   1f2cf:	add    %rbx,%r12
   1f2d2:	mov    %r12,%r15
   1f2d5:	mov    0x50(%rsp),%r12
   1f2da:	add    $0x4,%r12
eq<[u8; 4]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/non_null.rs:1709
   1f2de:	cmp    0x48(%rsp),%r12
   1f2e3:	mov    0x18(%rsp),%rbp
   1f2e8:	mov    0xb8(%rsp),%r13
next<[u8; 4]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/iter/macros.rs:180
   1f2f0:	je     1f6a2 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x432>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:240
   1f2f6:	movzwl (%r12),%edi
{closure#1}():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:240
   1f2fb:	movzbl 0x2(%r12),%ebx
   1f301:	movzbl 0x3(%r12),%r14d
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:420
   1f307:	cmp    $0xff,%r14
   1f30e:	mov    %rdi,0x18(%rsp)
   1f313:	jne    1f336 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0xc6>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1f315:	lea    0x58(%rsp),%rdi
   1f31a:	call   20190 <zxc_codec::block::extra>
   1f31f:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f322:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f324:	jne    1f710 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:421
   1f32a:	add    $0xff,%r14
   1f331:	mov    0x18(%rsp),%rdi
   1f336:	mov    %r12,0x50(%rsp)
   1f33b:	mov    %edi,%eax
   1f33d:	shl    $0x10,%eax
   1f340:	shl    $0x8,%ebx
   1f343:	or     %eax,%ebx
   1f345:	shr    $0x8,%ebx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1f348:	movzbl %bl,%r12d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:423
   1f34c:	add    $0x5,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:424
   1f350:	cmp    $0x104,%r12
   1f357:	mov    0xa0(%rsp),%rbx
   1f35f:	jne    1f382 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x112>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1f361:	lea    0x58(%rsp),%rdi
   1f366:	call   20190 <zxc_codec::block::extra>
   1f36b:	mov    %rdx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f36e:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f370:	jne    1f6ec <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x47c>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:425
   1f376:	add    $0x104,%r12
   1f37d:	mov    0x18(%rsp),%rdi
   1f382:	mov    0x40(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:428
   1f387:	sub    %r12,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:74
   1f38a:	jb     1f6d0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x460>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:432
   1f390:	mov    %rbx,%rax
   1f393:	mov    %rcx,0x40(%rsp)
   1f398:	sub    %rcx,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f39b:	mov    0x10(%r13),%r9
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:433
   1f39f:	cmp    %r9,%rax
   1f3a2:	jbe    1f40c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x19c>
   1f3a4:	mov    %rbx,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:434
   1f3a7:	lea    (%r9,%r9,1),%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1f3ab:	cmp    %rbx,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1f3ae:	cmova  %rax,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f3b2:	cmp    %rcx,%rbx
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f3b5:	cmovae %rcx,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1f3b9:	cmp    %r9,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1f3bc:	jbe    1f400 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x190>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1f3be:	sub    %r9,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1f3c1:	mov    0x0(%r13),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1f3c5:	sub    %r9,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1f3c8:	cmp    %rax,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1f3cb:	ja     1f679 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x409>
   1f3d1:	mov    %r9,0x8(%rsp)
spec_extend_with<u8, alloc::alloc::Global>():
   1f3d6:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f3da:	add    %r9,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f3dd:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f3df:	mov    %rbx,%rdx
   1f3e2:	call   *0x49618(%rip)        # 68a00 <memset@GLIBC_2.2.5>
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1f3e8:	add    0x8(%rsp),%rbx
   1f3ed:	mov    0x18(%rsp),%rdi
   1f3f2:	jmp    1f405 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x195>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f3f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1f400:	cmp    %r9,%rbx
   1f403:	jae    1f40c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x19c>
resize<u8, alloc::alloc::Global>():
   1f405:	mov    %rbx,0x10(%r13)
   1f409:	mov    %rbx,%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:436
   1f40c:	lea    (%r14,%r15,1),%rbx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1f410:	cmp    $0x8,%r14
   1f414:	mov    %r9,0x8(%rsp)
   1f419:	ja     1f433 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x1c3>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:449
   1f41b:	lea    0x8(%r15),%rsi
   1f41f:	cmp    %r9,%rsi
   1f422:	ja     1f42e <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x1be>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1f424:	cmp    $0x8,%rbp
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1f428:	jae    1f61e <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x3ae>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:454
   1f42e:	test   %r14,%r14
   1f431:	je     1f486 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x216>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1f433:	sub    %r14,%rbp
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1f436:	jb     1f6de <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x46e>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f43c:	cmp    %r15,%rbx
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f43f:	jb     1f740 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4d0>
   1f445:	cmp    %r9,%rbx
   1f448:	ja     1f740 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4d0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f44e:	mov    0x20(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1f453:	lea    (%rsi,%r14,1),%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f457:	mov    0xb8(%rsp),%rax
get_offset_len_mut_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f45f:	add    0x8(%rax),%r15
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f463:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f466:	mov    %r14,%rdx
   1f469:	call   *0x49411(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1f46f:	mov    0x18(%rsp),%rdi
   1f474:	mov    0x8(%rsp),%r9
   1f479:	mov    %r13,0x20(%rsp)
   1f47e:	mov    0xb8(%rsp),%r13
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f486:	inc    %edi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:459
   1f488:	mov    %rbx,%rsi
   1f48b:	sub    %rdi,%rsi
   1f48e:	mov    %rbp,0x18(%rsp)
   1f493:	jb     1f4f0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x280>
   1f495:	cmp    %rdi,%r12
   1f498:	ja     1f4f0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x280>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1f49a:	cmp    $0x9,%r12
   1f49e:	jae    1f5d0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x360>
   1f4a4:	lea    0x8(%rbx),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f4a8:	mov    0x8(%r13),%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1f4ac:	cmp    %r9,%rax
   1f4af:	ja     1f5da <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x36a>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:468
   1f4b5:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f4b9:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f4bc:	jb     1f890 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x620>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f4c2:	cmp    $0xfffffffffffffff8,%rsi
   1f4c6:	jae    1f884 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x614>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f4cc:	lea    -0x8(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f4d0:	cmp    %rax,%rbx
   1f4d3:	ja     1f7ae <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x53e>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f4d9:	mov    (%rdi,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f4dd:	mov    %rax,(%rdi,%rbx,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:467
   1f4e1:	jmp    1f2cf <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5f>
   1f4e6:	cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:477
   1f4f0:	cmp    %rdi,%rbx
   1f4f3:	jae    1f550 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x2e0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:480
   1f4f5:	mov    %rdi,%r14
   1f4f8:	sub    %rbx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f4fb:	mov    0xb0(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f503:	sub    %r14,%rsi
   1f506:	jb     1f6f6 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x486>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f50c:	cmp    %r14,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f50f:	cmovb  %r12,%r14
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:486
   1f513:	lea    (%r14,%rbx,1),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1f517:	cmp    %r9,%r15
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1f51a:	ja     1f76f <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4ff>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f520:	mov    0x8(%r13),%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f524:	add    %rbp,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f527:	add    0xa8(%rsp),%rsi
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f52f:	mov    %rdi,%r13
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f532:	mov    %rbx,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f535:	mov    %r14,%rdx
   1f538:	call   *0x49342(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1f53e:	mov    %r13,%rdi
   1f541:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:489
   1f546:	sub    %r14,%r12
   1f549:	jne    1f560 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x2f0>
   1f54b:	jmp    1f2d5 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1f550:	test   %r12,%r12
   1f553:	je     1f671 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x401>
   1f559:	mov    0x8(%r13),%rbp
   1f55d:	mov    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:493
   1f560:	mov    %r15,%r13
   1f563:	sub    %rdi,%r13
   1f566:	mov    %rbp,%rbx
   1f569:	add    %r13,%rbx
   1f56c:	nopl   0x0(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:496
   1f570:	mov    %r15,%r14
   1f573:	sub    %r13,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f576:	cmp    %r14,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f579:	cmovb  %r12,%r14
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:497
   1f57d:	lea    (%r14,%r13,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f581:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f584:	jb     1f7e7 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x577>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f58a:	cmp    %rax,%r13
   1f58d:	ja     1f7e0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x570>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f593:	sub    %r14,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f596:	cmp    %r9,%r15
   1f599:	ja     1f727 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4b7>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f59f:	lea    (%r15,%rbp,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f5a3:	mov    %rbx,%rsi
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f5a6:	mov    %r14,%rdx
   1f5a9:	call   *0x49459(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1f5af:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:498
   1f5b4:	add    %r14,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1f5b7:	sub    %r14,%r12
   1f5ba:	jne    1f570 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x300>
   1f5bc:	jmp    1f2d5 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
non_null<alloc::alloc::Global, u8>():
   1f5c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f5d0:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:469
   1f5d4:	cmp    $0x11,%r12
   1f5d8:	jae    1f5e3 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x373>
   1f5da:	lea    0x10(%rbx),%rax
   1f5de:	cmp    %r9,%rax
   1f5e1:	jbe    1f648 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x3d8>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:472
   1f5e3:	lea    (%r12,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f5e7:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f5ea:	jb     1f81c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5ac>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f5f0:	cmp    %rax,%rsi
   1f5f3:	ja     1f810 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5a0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f5f9:	sub    %r12,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f5fc:	cmp    %r9,%rbx
   1f5ff:	ja     1f756 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4e6>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f605:	add    %rdi,%rsi
   1f608:	add    %rbx,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f60b:	mov    %r12,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f60e:	call   *0x493f4(%rip)        # 68a08 <memmove@GLIBC_2.2.5>
   1f614:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:469
   1f619:	jmp    1f2cf <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5f>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f61e:	cmp    $0xfffffffffffffff8,%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f622:	jae    1f79b <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x52b>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f628:	mov    0x8(%r13),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f62c:	mov    0x20(%rsp),%rdx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f631:	mov    (%rdx),%rcx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f634:	mov    %rcx,(%rax,%r15,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1f638:	sub    %r14,%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f63b:	add    %r14,%rdx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f63e:	mov    %rdx,0x20(%rsp)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:448
   1f643:	jmp    1f486 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x216>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:470
   1f648:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f64c:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f64f:	jb     1f856 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5e6>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f655:	cmp    $0xfffffffffffffff0,%rsi
   1f659:	jae    1f84a <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5da>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f65f:	lea    -0x10(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f663:	cmp    %rax,%rbx
   1f666:	jbe    1f2c7 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x57>
   1f66c:	jmp    1f7c7 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x557>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f671:	mov    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:495
   1f674:	jmp    1f2d5 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1f679:	mov    $0x1,%ecx
   1f67e:	mov    $0x1,%r8d
   1f684:	mov    %r13,%rdi
   1f687:	mov    %r9,%rsi
   1f68a:	mov    %rbx,%rdx
   1f68d:	call   26430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f692:	mov    0x10(%r13),%r9
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f696:	jmp    1f3d1 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x161>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1f69b:	mov    0x10(%r13),%r9
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1f69f:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:502
   1f6a2:	mov    %r15,%r14
   1f6a5:	add    %rbp,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f6a8:	jb     1f785 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x515>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f6ae:	cmp    %r9,%r14
   1f6b1:	ja     1f785 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x515>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f6b7:	add    0x8(%r13),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f6bb:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f6be:	mov    0x20(%rsp),%rsi
   1f6c3:	mov    %rbp,%rdx
   1f6c6:	call   *0x491b4(%rip)        # 68880 <memcpy@GLIBC_2.14>
   1f6cc:	xor    %eax,%eax
   1f6ce:	jmp    1f715 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a5>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6d0:	lea    -0x13d3a(%rip),%rsi        # b99d <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6d7:	mov    $0x18,%edx
   1f6dc:	jmp    1f702 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x492>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6de:	lea    -0x127fe(%rip),%rsi        # cee7 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.1069639741503911768>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6e5:	mov    $0xd,%edx
   1f6ea:	jmp    1f702 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x492>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f6ec:	mov    $0x1,%eax
   1f6f1:	mov    %r12,%r14
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f6f4:	jmp    1f715 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a5>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6f6:	lea    -0x13d48(%rip),%rsi        # b9b5 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/lib.rs:71
   1f6fd:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f702:	mov    $0x15,%edi
   1f707:	call   *0x49303(%rip)        # 68a10 <_DYNAMIC+0x460>
   1f70d:	mov    %rax,%r14
   1f710:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-base/crates/codec/src/block.rs:504
   1f715:	mov    %r14,%rdx
   1f718:	add    $0x68,%rsp
   1f71c:	pop    %rbx
   1f71d:	pop    %r12
   1f71f:	pop    %r13
   1f721:	pop    %r14
   1f723:	pop    %r15
   1f725:	pop    %rbp
   1f726:	ret
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f727:	lea    -0x13da6(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f72e:	lea    0x46c3b(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1f735:	mov    $0x2b,%esi
   1f73a:	call   *0x492d8(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f740:	lea    0x46ca1(%rip),%rcx        # 663e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f747:	mov    %r15,%rdi
   1f74a:	mov    %rbx,%rsi
   1f74d:	mov    %r9,%rdx
   1f750:	call   *0x4926a(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f756:	lea    -0x13dd5(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f75d:	lea    0x46c3c(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1f764:	mov    $0x2b,%esi
   1f769:	call   *0x492a9(%rip)        # 68a18 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f76f:	lea    0x46c12(%rip),%rcx        # 66388 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5d0>
   1f776:	mov    %rbx,%rdi
   1f779:	mov    %r15,%rsi
   1f77c:	mov    %r9,%rdx
   1f77f:	call   *0x4923b(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f785:	lea    0x46c74(%rip),%rcx        # 66400 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x648>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f78c:	mov    %r15,%rdi
   1f78f:	mov    %r14,%rsi
   1f792:	mov    %r9,%rdx
   1f795:	call   *0x49225(%rip)        # 689c0 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f79b:	lea    0x46bb6(%rip),%rcx        # 66358 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f7a2:	mov    %r15,%rdi
   1f7a5:	mov    %r9,%rdx
   1f7a8:	call   *0x49212(%rip)        # 689c0 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f7ae:	lea    -0x13e2d(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f7b5:	lea    0x46c14(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1f7bc:	mov    $0x2b,%esi
   1f7c1:	call   *0x49251(%rip)        # 68a18 <_DYNAMIC+0x468>
   1f7c7:	lea    -0x13e46(%rip),%rdi        # b988 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.15561328414669180376+0xd98>
   1f7ce:	lea    0x46be3(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1f7d5:	mov    $0x2b,%esi
   1f7da:	call   *0x49238(%rip)        # 68a18 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f7e0:	mov    $0x1,%ecx
   1f7e5:	jmp    1f7ec <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x57c>
   1f7e7:	mov    %rax,%r13
   1f7ea:	xor    %ecx,%ecx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f7ec:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f7f1:	mov    %r13,0x30(%rsp)
   1f7f6:	mov    %rax,0x38(%rsp)
   1f7fb:	lea    0x46b6e(%rip),%rdx        # 66370 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5b8>
   1f802:	lea    0x28(%rsp),%rdi
   1f807:	mov    %r9,%rsi
   1f80a:	call   *0x49210(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f810:	mov    $0x1,%ecx
   1f815:	mov    %rcx,0x10(%rsp)
   1f81a:	jmp    1f81f <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5af>
   1f81c:	mov    %rax,%rsi
   1f81f:	mov    0x10(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f824:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f829:	mov    %rsi,0x30(%rsp)
   1f82e:	mov    %rax,0x38(%rsp)
   1f833:	lea    0x46b66(%rip),%rdx        # 663a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x5e8>
   1f83a:	lea    0x28(%rsp),%rdi
   1f83f:	mov    0x8(%rsp),%rsi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f844:	call   *0x491d6(%rip)        # 68a20 <_DYNAMIC+0x470>
   1f84a:	mov    $0x1,%ecx
   1f84f:	mov    %rcx,0x10(%rsp)
   1f854:	jmp    1f859 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5e9>
   1f856:	mov    %rax,%rsi
   1f859:	mov    0x10(%rsp),%rcx
   1f85e:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f863:	mov    %rsi,0x30(%rsp)
   1f868:	mov    %rax,0x38(%rsp)
   1f86d:	lea    0x46b44(%rip),%rdx        # 663b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x600>
   1f874:	lea    0x28(%rsp),%rdi
   1f879:	mov    0x8(%rsp),%rsi
   1f87e:	call   *0x4919c(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f884:	mov    $0x1,%ecx
   1f889:	mov    %rcx,0x10(%rsp)
   1f88e:	jmp    1f893 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x623>
   1f890:	mov    %rax,%rsi
   1f893:	mov    0x10(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f898:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f89d:	mov    %rsi,0x30(%rsp)
   1f8a2:	mov    %rax,0x38(%rsp)
   1f8a7:	lea    0x46b22(%rip),%rdx        # 663d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.5667876617746030756+0x618>
   1f8ae:	lea    0x28(%rsp),%rdi
   1f8b3:	mov    0x8(%rsp),%rsi
   1f8b8:	call   *0x49162(%rip)        # 68a20 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f8be:	int3
   1f8bf:	int3

