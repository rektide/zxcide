#!/usr/bin/env python3
"""Run/reduce two independently balanced perf series with interleaved Rust A/A."""
import argparse
from contextlib import ExitStack
import fcntl
import json
from math import comb
from pathlib import Path
import os
import platform
import random
import select
import statistics as st
import subprocess as sp
import sys

DOC = Path('doc/profiling').resolve()
sys.path.insert(0, str(DOC / 'decode-replay-data'))
from perf import MANIFEST, capture, identity, measure, request, snapshot
VECTORS = Path('tests/conformance/v9').resolve()
SEEDS = (904183, 117527)
FIXED = {
    'single-block': (1, ('copy', 'bucket')),
    'mozilla-block': (4, ('copy',)),
    'sao-block': (24, ('copy', 'bucket')),
    'small-block': (2048, ('copy',)),
    'single-tok': (16, ('bucket',)),
    'single-lit': (4, ('bucket',)),
    'sao-tok': (384, ('bucket',)),
}


def interval(xs):
    # Same order-statistic interval as decode-pool-data/bench.py.
    xs = sorted(xs)
    n = len(xs)
    tail = 0
    for k in range(n//2):
        tail += comb(n, k)
        if 40*tail > 2**n:
            rank = max(0, k - 1)
            return [xs[rank], xs[-1-rank]]
    return [xs[0], xs[-1]]


def exact(argv, path):
    with path.open('wb') as f:
        sp.run(argv, stdout=f, check=True)
    return {'argv': argv, **identity(path)}


def summaries(path):
    raw = json.loads(path.read_text())
    for name, case in raw['cases'].items():
        norm = case['repeats'] * case['units']
        for target in case['comparisons']:
            print(f'{name:16} {target}')
            for series in raw['series']:
                rows = [pair['samples'] for pair in series['cases'][name]['pairs'] if pair['target'] == target]
                desc = []
                for key, units in (('cycles:u', 'cycles'), ('instructions:u', 'insns'), ('thread_cpu_ns', 'ns CPU')):
                    a, b = zip(*[(row[0][key], row[1][key]) for row in rows])
                    ds = [100*(y/x-1) for x, y in zip(a, b)]
                    lo, hi = interval(ds)
                    desc.append(f'{st.median(a)/norm:.3f} → {st.median(b)/norm:.3f} {units}: '
                                f'{st.median(ds):+.2f}% [{lo:+.2f}, {hi:+.2f}]')
                print('  ' + '; '.join(desc))


def run_group(case, orders, cpu):
    with ExitStack() as stack:
        ws = {}
        for name, cmd in case['commands'].items():
            p = stack.enter_context(sp.Popen(cmd, stdin=sp.PIPE, stdout=sp.PIPE))
            stack.callback(p.stdin.close)
            ws[name] = p

        ready = {}
        for label, p in ws.items():
            assert os.sched_getaffinity(p.pid) == {cpu}
            assert len(list(Path(f'/proc/{p.pid}/task').iterdir())) == 1
            assert select.select([p.stdout], [], [], 60)[0], 'replay startup timeout'
            row = p.stdout.readline().decode().split()
            assert len(row) == 5 and row[:3] == ['ready', str(case['count']), str(case['units'])], row
            assert row[4] == ('bad-checksum-rejected' if case['kind'] == 'block' else 'bad-table-rejected')
            ready[label] = row
        assert all(row == ready['base'] for row in ready.values())
        warm = {label: request(w, case['repeats']) for label, w in ws.items()}
        pairs = []
        for target, first in orders:
            labels = ('base', target)
            samples = [None, None]
            for pos in (first, 1-first):
                samples[pos] = measure(ws[labels[pos]], case['repeats'])
            pairs.append(dict(target=target, first=first, samples=samples))
        for w in ws.values():
            w.stdin.close()
            assert w.wait(timeout=10) == 0
    return dict(ready=ready, warmup=warm, pairs=pairs)


def run(a):
    assert a.cpu in os.sched_getaffinity(0)
    a.out.mkdir()
    m = json.loads(MANIFEST.read_text())
    arcs = {r['file'].removesuffix('.zxc'): r for r in m['members']}
    arcs['single'] = {**m['single'], **{'plain_'+k: v for k, v in m['plain'].items()}}
    names = {name: val for name, val in FIXED.items() if not a.only or name in a.only}
    if a.confirm_bucket:
        names = {name: (FIXED[name][0], ('bucket',)) for name in ('single-block', 'single-tok')}
    variants = {'base', *[v for _, vs in names.values() for v in vs]}
    paths = {v: a.build/f'replay-{v}' for v in sorted(variants)}
    cls = {v: a.build/f'cli-{v}' for v in paths}
    raw = {'host': platform.uname()._asdict(), 'cpu': a.cpu, 'perf': sp.check_output(['perf', 'version'], text=True).strip(),
           'cpu_model': next(ln for ln in Path('/proc/cpuinfo').read_text().splitlines() if ln.startswith('model name')),
           'bins': {v: {'replay': identity(paths[v]), 'cli': identity(cls[v])} for v in paths},
           'fixtures': {}, 'cases': {}, 'series': []}
    with Path('.test-agent/zxc-perf.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for name, (repeats, vs) in names.items():
            fixture, kind = name.split('-')
            if fixture == 'small':
                stem = VECTORS/'valid/multiblock_checksum'
                archive = stem.with_suffix('.zxc')
                expect = stem.with_suffix('.expected')
                hashes = dict(line.split()[::-1] for line in (VECTORS / 'vectors.sha256').read_text().splitlines())
                arc, plain = identity(archive), identity(expect)
                for p, desc in [(archive, arc), (expect, plain)]:
                    assert desc['sha256'] == hashes[str(p.relative_to(Path.cwd()))]
                count, indexes = 16, {}
            else:
                archive = a.fixtures/f'{fixture}.zxc'
                expected = arcs[fixture]
                arc = identity(archive)
                assert arc == {k: expected[k] for k in arc}
                plain = {k: expected['plain_'+k] for k in arc}
                count, indexes = capture(archive, a.out)
            raw['fixtures'][fixture] = dict(path=str(archive), archive=arc, plain=plain)
            inputs = [str(archive)]
            if kind != 'block':
                idx = indexes[kind]
                inputs.append(idx['index']['path'])
                count, units = idx['count'], idx['units']
            else:
                units = plain['bytes']
            case = dict(count=count, kind=kind, units=units, repeats=repeats, comparisons=[*vs, 'aa'],
                        commands={}, verify={})
            proof = plain if kind == 'block' else None
            for v in ('base', *vs):
                pinned = ['taskset', '-c', str(a.cpu)]
                replay = exact([*pinned, str(paths[v]), 'verify', *inputs], a.out/'verify.tmp')
                result = {k: replay[k] for k in ('sha256', 'bytes')}
                proof = proof or result
                assert result == proof and result['bytes'] == units, replay
                case['verify'][v] = {'replay': replay}
                if kind == 'block':
                    cmd = [*pinned, str(cls[v]), 'decode', str(archive)]
                    output = exact(cmd, a.out/'verify.tmp')
                    assert all(output[k] == val for k, val in plain.items()), output
                    case['verify'][v]['cli'] = output
                case['commands'][v] = [*pinned, str(paths[v]), 'serve', *inputs]
            case['commands']['aa'] = case['commands']['base']
            raw['cases'][name] = case
        (a.out/'verify.tmp').unlink()
        for seed in ((329627, 440023) if a.confirm_bucket else SEEDS):
            rng = random.Random(seed)
            groups = list(names)
            rng.shuffle(groups)
            series = dict(seed=seed, before=snapshot(a.cpu), group_order=groups, cases={})
            for name in groups:
                case = raw['cases'][name]
                targets = case['comparisons']
                order = {target: rng.sample([0, 1]*12, 24) for target in targets}
                rounds = [pair for i in range(24) for pair in rng.sample([(t, order[t][i]) for t in targets], len(targets))]
                series['cases'][name] = run_group(case, rounds, a.cpu)
                print(seed, name, 'complete', flush=True)
            series['after'] = snapshot(a.cpu)
            raw['series'].append(series)
            (a.out/'pairs.json').write_text(json.dumps(raw, indent=2)+'\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--summary', type=Path)
    p.add_argument('--cpu', type=int, default=3)
    p.add_argument('--only', nargs='+', choices=FIXED)
    p.add_argument('--confirm-bucket', action='store_true')
    for name in ('fixtures', 'build', 'out'):
        p.add_argument(name, nargs='?', type=lambda arg: Path(arg).resolve())
    args = p.parse_args()
    summaries(args.summary) if args.summary else run(args)
