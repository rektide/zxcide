000000000001dea0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>>:
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:372
   1dea0:	push   %rbp
   1dea1:	push   %r15
   1dea3:	push   %r14
   1dea5:	push   %r13
   1dea7:	push   %r12
   1dea9:	push   %rbx
   1deaa:	sub    $0x78,%rsp
   1deae:	mov    %rdx,%rbp
   1deb1:	mov    %rsi,0x18(%rsp)
   1deb6:	mov    0xc0(%rsp),%r13
   1debe:	mov    %rcx,0x68(%rsp)
   1dec3:	mov    %r8,0x70(%rsp)
   1dec8:	mov    0x20(%rdi),%rax
   1decc:	mov    0x28(%rdi),%rcx
   1ded0:	mov    %rcx,0x58(%rsp)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1ded5:	cmp    %rcx,%rax
next<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1ded8:	jae    1df0c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x6c>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1deda:	mov    %r9,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:380
   1dedd:	mov    %r9,%rcx
   1dee0:	sub    %rbp,%rcx
   1dee3:	mov    %rcx,0x38(%rsp)
   1dee8:	mov    (%rdi),%rcx
   1deeb:	mov    %rcx,0x50(%rsp)
   1def0:	mov    0x10(%rdi),%rcx
   1def4:	mov    %rcx,0x48(%rsp)
   1def9:	movq   $0x0,0x8(%rsp)
   1df02:	xor    %r15d,%r15d
   1df05:	mov    %r9,0x40(%rsp)
   1df0a:	jmp    1df74 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xd4>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1df0c:	mov    0x10(%r13),%r9
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1df10:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:509
   1df13:	mov    %r15,%rbx
   1df16:	add    %rbp,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1df19:	jb     1e391 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4f1>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1df1f:	cmp    %r9,%rbx
   1df22:	ja     1e391 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4f1>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1df28:	add    0x8(%r13),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1df2c:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1df2f:	mov    0x18(%rsp),%rsi
   1df34:	mov    %rbp,%rdx
   1df37:	call   *0x4aad3(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1df3d:	xor    %eax,%eax
   1df3f:	jmp    1e350 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4b0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1df44:	movups (%rdi,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1df48:	movups %xmm0,(%rdi,%r12,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1df4d:	add    %r12,%r14
   1df50:	mov    %r14,%r15
   1df53:	mov    0x60(%rsp),%rax
   1df58:	inc    %rax
next<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/iter/adapters/zip.rs:300
   1df5b:	cmp    0x58(%rsp),%rax
   1df60:	mov    0x10(%rsp),%rbp
   1df65:	mov    0xc0(%rsp),%r13
   1df6d:	mov    0x40(%rsp),%r12
   1df72:	je     1df13 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x73>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1df74:	mov    0x50(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ops/function.rs:310
   1df79:	movzbl (%rcx,%rax,1),%r14d
call_once<((&u8, &u8)), zxc_codec::block::unpack_with_sections::{closure_env#2}>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ops/function.rs:310
   1df7e:	mov    %rax,0x60(%rsp)
   1df83:	mov    0x48(%rsp),%rcx
   1df88:	movzbl (%rcx,%rax,1),%edi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:254
   1df8c:	mov    %r14d,%ebx
{closure#2}():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:254
   1df8f:	shr    $0x4,%ebx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:427
   1df92:	cmp    $0xf,%rbx
   1df96:	mov    %rdi,0x10(%rsp)
   1df9b:	jne    1dfbb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x11b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1df9d:	lea    0x68(%rsp),%rdi
   1dfa2:	call   202c0 <zxc_codec::block::extra>
   1dfa7:	mov    %rdx,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1dfaa:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1dfac:	jne    1e34b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4ab>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1dfb2:	add    $0xf,%rbx
   1dfb6:	mov    0x10(%rsp),%rdi
   1dfbb:	and    $0xf,%r14d
   1dfbf:	mov    %edi,%eax
   1dfc1:	shl    $0x10,%eax
   1dfc4:	shl    $0x8,%r14d
   1dfc8:	or     %eax,%r14d
   1dfcb:	shr    $0x8,%r14d
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1dfcf:	movzbl %r14b,%r14d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:430
   1dfd3:	add    $0x5,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:431
   1dfd7:	cmp    $0x14,%r14
   1dfdb:	jne    1dffb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x15b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1dfdd:	lea    0x68(%rsp),%rdi
   1dfe2:	call   202c0 <zxc_codec::block::extra>
   1dfe7:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1dfea:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1dfec:	jne    1e327 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x487>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1dff2:	add    $0x14,%r14
   1dff6:	mov    0x10(%rsp),%rdi
   1dffb:	mov    0x38(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:435
   1e000:	sub    %r14,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:74
   1e003:	jb     1e30b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x46b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:439
   1e009:	mov    %r12,%rax
   1e00c:	mov    %rcx,0x38(%rsp)
   1e011:	sub    %rcx,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1e014:	mov    0x10(%r13),%r9
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:440
   1e018:	cmp    %r9,%rax
   1e01b:	jbe    1e07c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1dc>
   1e01d:	mov    %r12,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:441
   1e020:	lea    (%r9,%r9,1),%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1e024:	cmp    %r12,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1e027:	cmova  %rax,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e02b:	cmp    %rcx,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e02e:	cmovae %rcx,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1e032:	cmp    %r9,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1e035:	jbe    1e070 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1d0>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1e037:	sub    %r9,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1e03a:	mov    0x0(%r13),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1e03e:	sub    %r9,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1e041:	cmp    %rax,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1e044:	ja     1e2e9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x449>
   1e04a:	mov    %r9,(%rsp)
spec_extend_with<u8, alloc::alloc::Global>():
   1e04e:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1e052:	add    %r9,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e055:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e057:	mov    %r12,%rdx
   1e05a:	call   *0x4ab30(%rip)        # 68b90 <memset@GLIBC_2.2.5>
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1e060:	add    (%rsp),%r12
   1e064:	mov    0x10(%rsp),%rdi
   1e069:	jmp    1e075 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1d5>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e06b:	nopl   0x0(%rax,%rax,1)
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1e070:	cmp    %r9,%r12
   1e073:	jae    1e07c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1dc>
resize<u8, alloc::alloc::Global>():
   1e075:	mov    %r12,0x10(%r13)
   1e079:	mov    %r12,%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:443
   1e07c:	lea    (%rbx,%r15,1),%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1e080:	cmp    $0x8,%rbx
   1e084:	mov    %r9,(%rsp)
   1e088:	ja     1e0a2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x202>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:456
   1e08a:	lea    0x8(%r15),%rsi
   1e08e:	cmp    %r9,%rsi
   1e091:	ja     1e09d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1fd>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e093:	cmp    $0x8,%rbp
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e097:	jae    1e28e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3ee>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:461
   1e09d:	test   %rbx,%rbx
   1e0a0:	je     1e0f4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x254>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e0a2:	sub    %rbx,%rbp
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e0a5:	jb     1e319 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x479>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e0ab:	cmp    %r15,%r12
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e0ae:	jb     1e37b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4db>
   1e0b4:	cmp    %r9,%r12
   1e0b7:	ja     1e37b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4db>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e0bd:	mov    0x18(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1e0c2:	lea    (%rsi,%rbx,1),%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e0c6:	mov    0xc0(%rsp),%rax
get_offset_len_mut_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e0ce:	add    0x8(%rax),%r15
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e0d2:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e0d5:	mov    %rbx,%rdx
   1e0d8:	call   *0x4a932(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1e0de:	mov    0x10(%rsp),%rdi
   1e0e3:	mov    (%rsp),%r9
   1e0e7:	mov    %r13,0x18(%rsp)
   1e0ec:	mov    0xc0(%rsp),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e0f4:	inc    %edi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:466
   1e0f6:	mov    %r12,%rsi
   1e0f9:	sub    %rdi,%rsi
   1e0fc:	mov    %rbp,0x10(%rsp)
   1e101:	jb     1e160 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x2c0>
   1e103:	cmp    %rdi,%r14
   1e106:	ja     1e160 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x2c0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1e108:	cmp    $0x9,%r14
   1e10c:	jae    1e240 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3a0>
   1e112:	lea    0x8(%r12),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e117:	mov    0x8(%r13),%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1e11b:	cmp    %r9,%rax
   1e11e:	ja     1e24a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3aa>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:475
   1e124:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e128:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e12b:	jb     1e4d1 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x631>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e131:	cmp    $0xfffffffffffffff8,%rsi
   1e135:	jae    1e4c5 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x625>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e13b:	lea    -0x8(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e13f:	cmp    %rax,%r12
   1e142:	ja     1e3e9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x549>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e148:	mov    (%rdi,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e14c:	mov    %rax,(%rdi,%r12,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1e150:	jmp    1df4d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xad>
   1e155:	data16 cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:484
   1e160:	cmp    %rdi,%r12
   1e163:	jae    1e1d0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x330>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:487
   1e165:	mov    %rdi,%r13
   1e168:	sub    %r12,%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e16b:	mov    0xb8(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e173:	sub    %r13,%rsi
   1e176:	jb     1e331 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x491>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e17c:	cmp    %r13,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e17f:	cmovb  %r14,%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:493
   1e183:	lea    (%r12,%r13,1),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e187:	cmp    %r9,%r15
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e18a:	ja     1e3c0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x520>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e190:	mov    0xc0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e198:	mov    0x8(%rax),%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1e19c:	add    %rbx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e19f:	add    0xb0(%rsp),%rsi
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e1a7:	mov    %rdi,%rbp
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e1aa:	mov    %r12,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e1ad:	mov    %r13,%rdx
   1e1b0:	call   *0x4a85a(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1e1b6:	mov    %rbp,%rdi
   1e1b9:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:496
   1e1bd:	sub    %r13,%r14
   1e1c0:	jne    1e1e0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x340>
   1e1c2:	jmp    1df53 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
   1e1c7:	nopw   0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1e1d0:	test   %r14,%r14
   1e1d3:	je     1e2e1 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x441>
   1e1d9:	mov    0x8(%r13),%rbx
   1e1dd:	mov    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:500
   1e1e0:	mov    %r15,%rbp
   1e1e3:	sub    %rdi,%rbp
   1e1e6:	lea    (%rbx,%rbp,1),%r13
   1e1ea:	nopw   0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:503
   1e1f0:	mov    %r15,%r12
   1e1f3:	sub    %rbp,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e1f6:	cmp    %r12,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e1f9:	cmovb  %r14,%r12
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:504
   1e1fd:	lea    (%r12,%rbp,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e201:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e204:	jb     1e427 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x587>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e20a:	cmp    %rax,%rbp
   1e20d:	ja     1e41b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x57b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e213:	sub    %r12,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e216:	cmp    %r9,%r15
   1e219:	ja     1e362 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4c2>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1e21f:	lea    (%rbx,%r15,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e223:	mov    %r13,%rsi
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e226:	mov    %r12,%rdx
   1e229:	call   *0x4a969(%rip)        # 68b98 <memmove@GLIBC_2.2.5>
   1e22f:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:505
   1e233:	add    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1e236:	sub    %r12,%r14
   1e239:	jne    1e1f0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x350>
   1e23b:	jmp    1df53 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e240:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:476
   1e244:	cmp    $0x11,%r14
   1e248:	jae    1e254 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x3b4>
   1e24a:	lea    0x10(%r12),%rax
   1e24f:	cmp    %r9,%rax
   1e252:	jbe    1e2b8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x418>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:479
   1e254:	lea    (%r14,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e258:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e25b:	jb     1e45f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5bf>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e261:	cmp    %rax,%rsi
   1e264:	ja     1e453 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5b3>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e26a:	sub    %r14,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e26d:	cmp    %r9,%r12
   1e270:	ja     1e3a7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x507>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1e276:	add    %rdi,%rsi
   1e279:	add    %r12,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e27c:	mov    %r14,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e27f:	call   *0x4a913(%rip)        # 68b98 <memmove@GLIBC_2.2.5>
   1e285:	mov    (%rsp),%r9
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:476
   1e289:	jmp    1df4d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xad>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e28e:	cmp    $0xfffffffffffffff8,%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1e292:	jae    1e3d6 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x536>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e298:	mov    0x8(%r13),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e29c:	mov    0x18(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e2a1:	mov    (%rdx),%rcx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e2a4:	mov    %rcx,(%rax,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e2a8:	sub    %rbx,%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e2ab:	add    %rbx,%rdx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e2ae:	mov    %rdx,0x18(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1e2b3:	jmp    1e0f4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x254>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:477
   1e2b8:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e2bc:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e2bf:	jb     1e498 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5f8>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e2c5:	cmp    $0xfffffffffffffff0,%rsi
   1e2c9:	jae    1e48c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5ec>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e2cf:	lea    -0x10(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e2d3:	cmp    %rax,%r12
   1e2d6:	jbe    1df44 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xa4>
   1e2dc:	jmp    1e402 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x562>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e2e1:	mov    %r12,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1e2e4:	jmp    1df53 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0xb3>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1e2e9:	mov    $0x1,%ecx
   1e2ee:	mov    $0x1,%r8d
   1e2f4:	mov    %r13,%rdi
   1e2f7:	mov    %r9,%rsi
   1e2fa:	mov    %r12,%rdx
   1e2fd:	call   26560 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1e302:	mov    0x10(%r13),%r9
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1e306:	jmp    1e04a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x1aa>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e30b:	lea    -0x12915(%rip),%rsi        # b9fd <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e312:	mov    $0x18,%edx
   1e317:	jmp    1e33d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x49d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e319:	lea    -0x113d9(%rip),%rsi        # cf47 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.11502846294190540699>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e320:	mov    $0xd,%edx
   1e325:	jmp    1e33d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x49d>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e327:	mov    $0x1,%eax
   1e32c:	mov    %r14,%rbx
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1e32f:	jmp    1e350 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x4b0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e331:	lea    -0x12923(%rip),%rsi        # ba15 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1e338:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e33d:	mov    $0x15,%edi
   1e342:	call   *0x4a858(%rip)        # 68ba0 <_DYNAMIC+0x460>
   1e348:	mov    %rax,%rbx
   1e34b:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:511
   1e350:	mov    %rbx,%rdx
   1e353:	add    $0x78,%rsp
   1e357:	pop    %rbx
   1e358:	pop    %r12
   1e35a:	pop    %r13
   1e35c:	pop    %r14
   1e35e:	pop    %r15
   1e360:	pop    %rbp
   1e361:	ret
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e362:	lea    -0x12981(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1e369:	lea    0x48130(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1e370:	mov    $0x2b,%esi
   1e375:	call   *0x4a82d(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e37b:	lea    0x48196(%rip),%rcx        # 66518 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e382:	mov    %r15,%rdi
   1e385:	mov    %r12,%rsi
   1e388:	mov    %r9,%rdx
   1e38b:	call   *0x4a7bf(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e391:	lea    0x48198(%rip),%rcx        # 66530 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x648>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e398:	mov    %r15,%rdi
   1e39b:	mov    %rbx,%rsi
   1e39e:	mov    %r9,%rdx
   1e3a1:	call   *0x4a7a9(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e3a7:	lea    -0x129c6(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1e3ae:	lea    0x4811b(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1e3b5:	mov    $0x2b,%esi
   1e3ba:	call   *0x4a7e8(%rip)        # 68ba8 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e3c0:	lea    0x480f1(%rip),%rcx        # 664b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5d0>
   1e3c7:	mov    %r12,%rdi
   1e3ca:	mov    %r15,%rsi
   1e3cd:	mov    %r9,%rdx
   1e3d0:	call   *0x4a77a(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e3d6:	lea    0x480ab(%rip),%rcx        # 66488 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1e3dd:	mov    %r15,%rdi
   1e3e0:	mov    %r9,%rdx
   1e3e3:	call   *0x4a767(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e3e9:	lea    -0x12a08(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1e3f0:	lea    0x48109(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1e3f7:	mov    $0x2b,%esi
   1e3fc:	call   *0x4a7a6(%rip)        # 68ba8 <_DYNAMIC+0x468>
   1e402:	lea    -0x12a21(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1e409:	lea    0x480d8(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1e410:	mov    $0x2b,%esi
   1e415:	call   *0x4a78d(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e41b:	mov    $0x1,%ecx
   1e420:	mov    %rcx,0x8(%rsp)
   1e425:	jmp    1e42a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x58a>
   1e427:	mov    %rax,%rbp
   1e42a:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e42f:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e434:	mov    %rbp,0x28(%rsp)
   1e439:	mov    %rax,0x30(%rsp)
   1e43e:	lea    0x4805b(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1e445:	lea    0x20(%rsp),%rdi
   1e44a:	mov    %r9,%rsi
   1e44d:	call   *0x4a75d(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e453:	mov    $0x1,%ecx
   1e458:	mov    %rcx,0x8(%rsp)
   1e45d:	jmp    1e462 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5c2>
   1e45f:	mov    %rax,%rsi
   1e462:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e467:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e46c:	mov    %rsi,0x28(%rsp)
   1e471:	mov    %rax,0x30(%rsp)
   1e476:	lea    0x48053(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1e47d:	lea    0x20(%rsp),%rdi
   1e482:	mov    (%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e486:	call   *0x4a724(%rip)        # 68bb0 <_DYNAMIC+0x470>
   1e48c:	mov    $0x1,%ecx
   1e491:	mov    %rcx,0x8(%rsp)
   1e496:	jmp    1e49b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x5fb>
   1e498:	mov    %rax,%rsi
   1e49b:	mov    0x8(%rsp),%rcx
   1e4a0:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e4a5:	mov    %rsi,0x28(%rsp)
   1e4aa:	mov    %rax,0x30(%rsp)
   1e4af:	lea    0x48032(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1e4b6:	lea    0x20(%rsp),%rdi
   1e4bb:	mov    (%rsp),%rsi
   1e4bf:	call   *0x4a6eb(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e4c5:	mov    $0x1,%ecx
   1e4ca:	mov    %rcx,0x8(%rsp)
   1e4cf:	jmp    1e4d4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>+0x634>
   1e4d1:	mov    %rax,%rsi
   1e4d4:	mov    0x8(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e4d9:	mov    %rcx,0x20(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1e4de:	mov    %rsi,0x28(%rsp)
   1e4e3:	mov    %rax,0x30(%rsp)
   1e4e8:	lea    0x48011(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1e4ef:	lea    0x20(%rsp),%rdi
   1e4f4:	mov    (%rsp),%rsi
   1e4f8:	call   *0x4a6b2(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::iter::adapters::zip::Zip<core::slice::iter::Iter<u8>, core::slice::iter::Iter<u8>>, zxc_codec::block::unpack_with_sections::{closure#2}>>>:
   1e4fe:	int3
   1e4ff:	int3

000000000001e500 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>>:
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:372
   1e500:	push   %rbp
   1e501:	push   %r15
   1e503:	push   %r14
   1e505:	push   %r13
   1e507:	push   %r12
   1e509:	push   %rbx
   1e50a:	sub    $0x98,%rsp
   1e511:	mov    %rdx,%r13
   1e514:	mov    %rsi,0x28(%rsp)
   1e519:	mov    0xe0(%rsp),%rax
   1e521:	mov    %rcx,0x78(%rsp)
   1e526:	mov    %r8,0x80(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:380
   1e52e:	mov    %r9,%rbx
   1e531:	sub    %rdx,%rbx
   1e534:	mov    (%rdi),%rcx
   1e537:	mov    %rcx,0x60(%rsp)
   1e53c:	mov    0x8(%rdi),%rcx
   1e540:	mov    %rcx,0x58(%rsp)
   1e545:	mov    %r9,0x88(%rsp)
   1e54d:	lea    0x2b(%r9),%rcx
   1e551:	mov    %rcx,0x90(%rsp)
   1e559:	mov    0x18(%rdi),%rcx
   1e55d:	mov    %rcx,0x30(%rsp)
   1e562:	mov    %rdi,0x70(%rsp)
   1e567:	mov    0x10(%rdi),%r11
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e56b:	mov    0x8(%rax),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1e56f:	mov    %rax,0x8(%rsp)
   1e574:	movq   $0x0,0x18(%rsp)
   1e57d:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e580:	mov    0x78(%rsp),%rcx
   1e585:	mov    0x80(%rsp),%r8
   1e58d:	mov    %r15,0x10(%rsp)
   1e592:	mov    0x60(%rsp),%r14
   1e597:	mov    0x58(%rsp),%r12
   1e59c:	jmp    1e5f4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xf4>
   1e59e:	xchg   %ax,%ax
   1e5a0:	mov    %r15,%r13
   1e5a3:	mov    0x8(%rsp),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e5a8:	movups (%rdx,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1e5ac:	movups 0x10(%rdx,%rsi,1),%xmm1
   1e5b1:	movups 0x20(%rdx,%rsi,1),%xmm2
   1e5b6:	movups 0x30(%rdx,%rsi,1),%xmm3
   1e5bb:	movups %xmm3,0x30(%rdx,%rax,1)
   1e5c0:	movups %xmm2,0x20(%rdx,%rax,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e5c5:	movups %xmm1,0x10(%rdx,%rax,1)
   1e5ca:	movups %xmm0,(%rdx,%rax,1)
   1e5ce:	inc    %rcx
   1e5d1:	dec    %r8
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:419
   1e5d4:	add    %rax,%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:421
   1e5d7:	mov    %rcx,0x78(%rsp)
   1e5dc:	mov    %r8,0x80(%rsp)
   1e5e4:	mov    %r10,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e5e7:	add    %r9,0x28(%rsp)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e5ec:	sub    %r9,%r13
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e5ef:	mov    %rdi,0x10(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1e5f4:	mov    0xe0(%rsp),%rax
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1e5fc:	mov    0x10(%rax),%rbp
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e600:	cmp    $0x2,%r12
first_chunk<u8, 2>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e604:	jae    1e620 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x120>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e606:	test   %r12,%r12
split_first<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e609:	jne    1e840 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x340>
   1e60f:	jmp    1ef47 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa47>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e614:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   1e620:	mov    0x88(%rsp),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e628:	cmp    %rax,%rbp
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1e62b:	cmovb  %rbp,%rax
   1e62f:	cmp    $0x1e,%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:335
   1e633:	jb     1e840 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x340>
batch():
   1e639:	mov    0x90(%rsp),%rdx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:335
   1e641:	sub    %rbx,%rdx
   1e644:	cmp    %rax,%rdx
   1e647:	ja     1e840 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x340>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e64d:	cmpq   $0x1,0x30(%rsp)
split_at_checked<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1e653:	jbe    1f08b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb8b>
batch():
   1e659:	mov    %r13,%r15
   1e65c:	movzwl (%r14),%r10d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:338
   1e660:	movzwl (%r11),%edx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:340
   1e664:	mov    %r10d,%r9d
   1e667:	shr    $0x4,%r9d
   1e66b:	and    $0xf,%r9d
   1e66f:	mov    %rbx,%r13
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:343
   1e672:	cmp    $0xf,%r9d
   1e676:	je     1e85a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x35a>
   1e67c:	mov    %r10d,%edi
   1e67f:	and    $0xf,%edi
   1e682:	add    $0x5,%rdi
   1e686:	cmp    $0x14,%edi
   1e689:	je     1e85a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x35a>
   1e68f:	movzwl %dx,%ebx
   1e692:	mov    0x10(%rsp),%rax
   1e697:	add    %r9,%rax
   1e69a:	cmp    %rbx,%rax
   1e69d:	jbe    1e85a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x35a>
   1e6a3:	inc    %rbx
   1e6a6:	cmp    %edi,%ebx
   1e6a8:	jb     1e85a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x35a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e6ae:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e6b1:	sub    0x10(%rsp),%rdx
   1e6b6:	jb     1f098 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb98>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e6bc:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e6c0:	jbe    1f0b0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbb0>
batch():
   1e6c6:	mov    %r15,0x50(%rsp)
   1e6cb:	mov    %r11,0x20(%rsp)
   1e6d0:	movzwl 0x2(%r11),%r11d
   1e6d5:	mov    0x28(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e6da:	movups (%rdx),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e6dd:	mov    0x8(%rsp),%rdx
   1e6e2:	mov    0x10(%rsp),%rsi
   1e6e7:	movups %xmm0,(%rdx,%rsi,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:349
   1e6eb:	mov    %rax,%rsi
   1e6ee:	sub    %rbx,%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e6f1:	mov    %rbp,%rdx
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e6f4:	sub    %rsi,%rdx
   1e6f7:	jb     1f0c4 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbc4>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e6fd:	cmp    $0x18,%rdx
first_chunk<u8, 24>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e701:	jb     1f0da <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbda>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e707:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e70a:	sub    %rax,%rdx
   1e70d:	jb     1f0e7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbe7>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e713:	cmp    $0x17,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e717:	jbe    1f0fd <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xbfd>
batch():
   1e71d:	mov    0x8(%rsp),%rbx
   1e722:	add    %rbx,%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e725:	movups (%rsi),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e728:	mov    0x10(%rsi),%rdx
   1e72c:	mov    %rdx,0x10(%rbx,%rax,1)
   1e731:	movups %xmm0,(%rbx,%rax,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:351
   1e735:	add    %rax,%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:353
   1e738:	mov    %r10d,%esi
   1e73b:	shr    $0xc,%esi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:356
   1e73e:	cmp    $0xf,%esi
   1e741:	je     1e9f8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4f8>
   1e747:	shr    $0x8,%r10d
   1e74b:	and    $0xf,%r10d
   1e74f:	add    $0x5,%r10
   1e753:	cmp    $0x14,%r10d
   1e757:	je     1e9f8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4f8>
   1e75d:	lea    (%rdi,%rsi,1),%rax
   1e761:	cmp    %r11,%rax
   1e764:	jbe    1e9f8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4f8>
   1e76a:	inc    %r11
   1e76d:	cmp    %r10d,%r11d
   1e770:	jb     1e9f8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4f8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e776:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e779:	sub    %rdi,%rdx
   1e77c:	jb     1f129 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc29>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e782:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e786:	jbe    1f13c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc3c>
batch():
   1e78c:	mov    0x28(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e791:	movups (%rdx,%r9,1),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e796:	mov    0x8(%rsp),%rdx
   1e79b:	movups %xmm0,(%rdx,%rdi,1)
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:364
   1e79f:	mov    %rax,%rdi
   1e7a2:	sub    %r11,%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e7a5:	mov    %rbp,%rdx
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e7a8:	sub    %rdi,%rdx
   1e7ab:	jb     1f150 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc50>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e7b1:	cmp    $0x18,%rdx
first_chunk<u8, 24>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e7b5:	jb     1f163 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc63>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e7bb:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e7be:	sub    %rax,%rdx
   1e7c1:	jb     1f170 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc70>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e7c7:	cmp    $0x17,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e7cb:	jbe    1f186 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc86>
batch():
   1e7d1:	mov    %r13,%rbx
   1e7d4:	mov    0x20(%rsp),%r13
   1e7d9:	add    $0x4,%r13
   1e7dd:	mov    0x30(%rsp),%r11
   1e7e2:	add    $0xfffffffffffffffe,%r11
   1e7e6:	mov    0x8(%rsp),%rbp
   1e7eb:	add    %rbp,%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e7ee:	movups (%rdi),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e7f1:	mov    0x10(%rdi),%rdx
   1e7f5:	mov    %rdx,0x10(%rbp,%rax,1)
   1e7fa:	movups %xmm0,0x0(%rbp,%rax,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1e7ff:	add    $0xfffffffffffffffe,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e803:	add    $0x2,%r14
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1e807:	mov    0x70(%rsp),%rdx
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:366
   1e80c:	mov    %r14,(%rdx)
   1e80f:	mov    %r12,0x8(%rdx)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:367
   1e813:	mov    %r13,0x10(%rdx)
   1e817:	mov    %r11,0x30(%rsp)
   1e81c:	mov    %r11,0x18(%rdx)
   1e820:	mov    %r13,%r11
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:368
   1e823:	add    %rsi,%r9
   1e826:	add    %rax,%r10
   1e829:	mov    %r10,%rdi
   1e82c:	jmp    1ea2b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x52b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e831:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
split_first<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e840:	cmpq   $0x0,0x30(%rsp)
   1e846:	je     1efd5 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xad5>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e84c:	mov    %r13,%r15
next():
   1e84f:	mov    %rbx,%r13
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:321
   1e852:	movzbl (%r14),%r10d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:322
   1e856:	movzwl (%r11),%edx
split_first<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e85a:	dec    %r12
   1e85d:	inc    %r14
split_first<[u8; 2]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:201
   1e860:	add    $0x2,%r11
   1e864:	mov    0x30(%rsp),%rsi
   1e869:	dec    %rsi
   1e86c:	mov    0x70(%rsp),%rax
   1e871:	mov    %r14,0x60(%rsp)
next():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:323
   1e876:	mov    %r14,(%rax)
   1e879:	mov    %r12,0x58(%rsp)
   1e87e:	mov    %r12,0x8(%rax)
   1e882:	mov    %r11,0x20(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:324
   1e887:	mov    %r11,0x10(%rax)
   1e88b:	mov    %rsi,0x30(%rsp)
   1e890:	mov    %rsi,0x18(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:325
   1e894:	mov    %r10d,%eax
   1e897:	shr    $0x4,%al
   1e89a:	and    $0xf,%r10b
   1e89e:	mov    %edx,%esi
   1e8a0:	shl    $0x10,%esi
   1e8a3:	movzbl %r10b,%r14d
   1e8a7:	shl    $0x8,%r14d
   1e8ab:	or     %esi,%r14d
   1e8ae:	movzbl %al,%eax
   1e8b1:	lea    (%r14,%rax,1),%ebx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:389
   1e8b5:	shr    $0x8,%r14d
   1e8b9:	movzwl %dx,%r12d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:395
   1e8bd:	cmp    $0xf,%al
   1e8bf:	je     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e8c5:	cmp    $0xf,%r14b
   1e8c9:	jne    1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e8cf:	test   %r8,%r8
   1e8d2:	je     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:397
   1e8d8:	movzbl (%rcx),%r11d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:399
   1e8dc:	lea    0x14(%r11),%rdi
   1e8e0:	mov    %r13,%r10
   1e8e3:	sub    %rdi,%r10
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:403
   1e8e6:	jb     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e8ec:	mov    %ebx,%r9d
   1e8ef:	and    $0xf,%r9d
   1e8f3:	mov    0x10(%rsp),%rax
   1e8f8:	add    %r9,%rax
   1e8fb:	lea    0x1(%r12),%edx
   1e900:	mov    %rax,%rsi
   1e903:	sub    %rdx,%rsi
   1e906:	jb     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e90c:	cmp    $0x2c,%r11b
   1e910:	ja     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e916:	cmp    %edx,%edi
   1e918:	ja     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:407
   1e91e:	lea    0x40(%rax),%rdx
   1e922:	cmp    %rbp,%rdx
   1e925:	ja     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
   1e92b:	cmp    $0x10,%r15
   1e92f:	jb     1ea40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x540>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e935:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e938:	mov    0x10(%rsp),%rbx
   1e93d:	sub    %rbx,%rdx
   1e940:	jb     1efe2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xae2>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e946:	cmp    $0xf,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e94a:	jbe    1eff8 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xaf8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e950:	mov    0x28(%rsp),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e955:	movups (%rdx),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e958:	mov    0x8(%rsp),%rdx
   1e95d:	movups %xmm0,(%rdx,%rbx,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:411
   1e961:	cmp    $0xd,%r11b
   1e965:	jae    1e9c0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x4c0>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e967:	mov    %rbp,%rdx
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:544
   1e96a:	sub    %rsi,%rdx
   1e96d:	mov    0x60(%rsp),%r14
   1e972:	mov    0x58(%rsp),%r12
   1e977:	mov    0x20(%rsp),%r11
   1e97c:	jb     1f025 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb25>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e982:	cmp    $0x20,%rdx
first_chunk<u8, 32>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1e986:	jb     1f054 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb54>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e98c:	mov    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:557
   1e98f:	sub    %rax,%rdx
   1e992:	jb     1f061 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb61>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e998:	cmp    $0x1f,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1e99c:	jbe    1f077 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb77>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e9a2:	mov    %r15,%r13
   1e9a5:	mov    0x8(%rsp),%rdx
   1e9aa:	add    %rdx,%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e9ad:	movups (%rsi),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1e9b0:	movups 0x10(%rsi),%xmm1
   1e9b4:	jmp    1e5c5 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc5>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e9b9:	nopl   0x0(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:417
   1e9c0:	lea    0x40(%rsi),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e9c4:	cmp    %rdx,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1e9c7:	mov    0x60(%rsp),%r14
   1e9cc:	mov    0x58(%rsp),%r12
   1e9d1:	mov    0x20(%rsp),%r11
   1e9d6:	jb     1f28e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd8e>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1e9dc:	cmp    $0xffffffffffffffc0,%rsi
   1e9e0:	jae    1f282 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd82>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e9e6:	add    $0xffffffffffffffc0,%rbp
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1e9ea:	cmp    %rbp,%rax
   1e9ed:	jbe    1e5a0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa0>
   1e9f3:	jmp    1f03b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb3b>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1e9f8:	mov    0x20(%rsp),%r11
   1e9fd:	add    $0x2,%r11
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1ea01:	dec    %r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ea04:	inc    %r14
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ea07:	mov    0x70(%rsp),%rax
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:359
   1ea0c:	mov    %r14,(%rax)
   1ea0f:	mov    %r12,0x8(%rax)
   1ea13:	mov    0x30(%rsp),%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1ea18:	dec    %rdx
batch():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:360
   1ea1b:	mov    %r11,0x10(%rax)
   1ea1f:	mov    %rdx,0x30(%rsp)
   1ea24:	mov    %rdx,0x18(%rax)
   1ea28:	mov    %r13,%rbx
   1ea2b:	add    0x10(%rsp),%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:386
   1ea30:	sub    %rdi,%rbx
   1ea33:	add    %r9,%rbx
   1ea36:	mov    0x50(%rsp),%r13
   1ea3b:	jmp    1e5e7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe7>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1ea40:	and    $0xf,%ebx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:427
   1ea43:	cmp    $0xf,%rbx
   1ea47:	jne    1ea62 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x562>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1ea49:	lea    0x78(%rsp),%rdi
   1ea4e:	call   202c0 <zxc_codec::block::extra>
   1ea53:	mov    %rdx,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1ea56:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1ea58:	jne    1efbb <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xabb>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1ea5e:	add    $0xf,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1ea62:	movzbl %r14b,%r14d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:430
   1ea66:	add    $0x5,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:431
   1ea6a:	cmp    $0x14,%r14
   1ea6e:	jne    1ea89 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x589>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1ea70:	lea    0x78(%rsp),%rdi
   1ea75:	call   202c0 <zxc_codec::block::extra>
   1ea7a:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1ea7d:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1ea7f:	jne    1ef97 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa97>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1ea85:	add    $0x14,%r14
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:435
   1ea89:	sub    %r14,%r13
   1ea8c:	mov    0x88(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:74
   1ea94:	jb     1ef7b <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa7b>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:439
   1ea9a:	mov    %rcx,%rax
   1ea9d:	mov    %r13,0x68(%rsp)
   1eaa2:	sub    %r13,%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:440
   1eaa5:	cmp    %rbp,%rax
   1eaa8:	jbe    1eb20 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x620>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:441
   1eaaa:	lea    0x0(,%rbp,2),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1eab2:	cmp    %rdx,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1eab5:	cmova  %rax,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1eab9:	cmp    %rcx,%rdx
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1eabc:	cmovae %rcx,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1eac0:	cmp    %rbp,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1eac3:	mov    0x20(%rsp),%r11
   1eac8:	mov    %r15,%r13
   1eacb:	jbe    1eb2a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x62a>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1eacd:	sub    %rbp,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1ead0:	mov    0xe0(%rsp),%rax
capacity<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1ead8:	mov    (%rax),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1eadb:	sub    %rbp,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1eade:	cmp    %rax,%rdx
needs_to_grow<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1eae1:	mov    %rdx,%r15
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1eae4:	ja     1ef18 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa18>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eaea:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eaf2:	mov    0x8(%rax),%rax
   1eaf6:	mov    %rax,0x8(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1eafb:	lea    (%rax,%rbp,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eaff:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eb01:	mov    %r15,%rdx
   1eb04:	call   *0x4a086(%rip)        # 68b90 <memset@GLIBC_2.2.5>
   1eb0a:	mov    %r15,%rdx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1eb0d:	add    %rbp,%rdx
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1eb10:	mov    0x20(%rsp),%r11
   1eb15:	jmp    1eb2f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x62f>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eb17:	nopw   0x0(%rax,%rax,1)
   1eb20:	mov    0x20(%rsp),%r11
   1eb25:	mov    %r15,%r13
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:440
   1eb28:	jmp    1eb3e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x63e>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1eb2a:	cmp    %rbp,%rdx
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1eb2d:	jae    1eb3e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x63e>
resize<u8, alloc::alloc::Global>():
   1eb2f:	mov    0xe0(%rsp),%rax
   1eb37:	mov    %rdx,0x10(%rax)
   1eb3b:	mov    %rdx,%rbp
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1eb3e:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:443
   1eb43:	lea    (%rbx,%rax,1),%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:449
   1eb47:	cmp    $0x20,%rbx
   1eb4b:	ja     1eb90 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x690>
   1eb4d:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:450
   1eb52:	lea    0x20(%rax),%rsi
   1eb56:	cmp    %rbp,%rsi
   1eb59:	ja     1eb65 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x665>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eb5b:	cmp    $0x20,%r13
first_chunk<u8, 32>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eb5f:	jae    1eda2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8a2>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1eb65:	cmp    $0x9,%rbx
   1eb69:	jae    1eb90 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x690>
   1eb6b:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:456
   1eb70:	lea    0x8(%rax),%rsi
   1eb74:	cmp    %rbp,%rsi
   1eb77:	ja     1eb83 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x683>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eb79:	cmp    $0x8,%r13
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1eb7d:	jae    1eedc <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x9dc>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:461
   1eb83:	test   %rbx,%rbx
   1eb86:	je     1ebec <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x6ec>
   1eb88:	nopl   0x0(%rax,%rax,1)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1eb90:	sub    %rbx,%r13
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1eb93:	jb     1ef89 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xa89>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eb99:	cmp    0x10(%rsp),%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eb9e:	jb     1f111 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc11>
   1eba4:	cmp    %rbp,%r15
   1eba7:	ja     1f111 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc11>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ebad:	mov    %r13,0x50(%rsp)
   1ebb2:	mov    0x28(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1ebb7:	lea    (%rsi,%rbx,1),%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ebbb:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ebc3:	mov    0x8(%rax),%rax
   1ebc7:	mov    %rax,0x8(%rsp)
   1ebcc:	mov    0x10(%rsp),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ebd1:	add    %rax,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ebd4:	mov    %rbx,%rdx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ebd7:	call   *0x49e33(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1ebdd:	mov    0x20(%rsp),%r11
   1ebe2:	mov    %r13,0x28(%rsp)
   1ebe7:	mov    0x50(%rsp),%r13
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ebec:	inc    %r12d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:466
   1ebef:	mov    %r15,%rsi
   1ebf2:	sub    %r12,%rsi
   1ebf5:	mov    0x68(%rsp),%rbx
   1ebfa:	jb     1ec80 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x780>
   1ec00:	cmp    %r12,%r14
   1ec03:	ja     1ec80 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x780>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:472
   1ec05:	cmp    $0x19,%r14
   1ec09:	mov    0x49f88(%rip),%rcx        # 68b98 <memmove@GLIBC_2.2.5>
   1ec10:	jae    1ee90 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x990>
   1ec16:	lea    0x18(%r15),%rax
   1ec1a:	cmp    %rbp,%rax
   1ec1d:	jbe    1ede7 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x8e7>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1ec23:	cmp    $0x9,%r14
   1ec27:	jae    1ee37 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x937>
   1ec2d:	lea    0x8(%r15),%rax
   1ec31:	cmp    %rbp,%rax
   1ec34:	ja     1ee3d <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x93d>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:475
   1ec3a:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ec3e:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ec41:	jb     1f36e <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe6e>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ec47:	cmp    $0xfffffffffffffff8,%rsi
   1ec4b:	jae    1f362 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe62>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ec51:	add    $0xfffffffffffffff8,%rbp
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ec55:	cmp    %rbp,%r15
   1ec58:	ja     1f231 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd31>
   1ec5e:	mov    0xe0(%rsp),%rax
   1ec66:	mov    0x8(%rax),%rcx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ec6a:	mov    (%rcx,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ec6e:	mov    %rcx,0x8(%rsp)
   1ec73:	mov    %rax,(%rcx,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1ec77:	add    %r14,%r15
   1ec7a:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
   1ec7f:	nop
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:484
   1ec80:	cmp    %r12,%r15
   1ec83:	jae    1ecf2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x7f2>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:487
   1ec85:	mov    %r12,%rbx
   1ec88:	sub    %r15,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ec8b:	mov    0xd8(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ec93:	sub    %rbx,%rsi
   1ec96:	jb     1efa1 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xaa1>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ec9c:	cmp    %rbx,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ec9f:	cmovb  %r14,%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:493
   1eca3:	lea    (%rbx,%r15,1),%rdx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1eca7:	cmp    %rbp,%rdx
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1ecaa:	ja     1f1c9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcc9>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ecb0:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1ecb8:	mov    0x8(%rax),%rax
   1ecbc:	mov    %rax,0x8(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ecc1:	add    %rax,%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ecc4:	add    0xd0(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eccc:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eccf:	mov    %rdx,%r15
   1ecd2:	mov    %rbx,%rdx
   1ecd5:	call   *0x49d35(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1ecdb:	mov    %r15,%rcx
   1ecde:	mov    0x20(%rsp),%r11
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:496
   1ece3:	sub    %rbx,%r14
   1ece6:	mov    0x68(%rsp),%rbx
   1eceb:	jne    1ed0f <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80f>
   1eced:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1ecf2:	test   %r14,%r14
   1ecf5:	je     1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
   1ecfb:	mov    0xe0(%rsp),%rax
   1ed03:	mov    0x8(%rax),%rax
   1ed07:	mov    %rax,0x8(%rsp)
   1ed0c:	mov    %r15,%rcx
   1ed0f:	mov    %r13,0x50(%rsp)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:500
   1ed14:	mov    %rcx,%r13
   1ed17:	sub    %r12,%r13
   1ed1a:	mov    0x8(%rsp),%rax
   1ed1f:	add    %r13,%rax
   1ed22:	mov    %rax,0x10(%rsp)
   1ed27:	mov    %rcx,%r15
   1ed2a:	mov    0x49e67(%rip),%r12        # 68b98 <memmove@GLIBC_2.2.5>
   1ed31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:503
   1ed40:	mov    %r15,%rbx
   1ed43:	sub    %r13,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ed46:	cmp    %rbx,%r14
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1ed49:	cmovb  %r14,%rbx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:504
   1ed4d:	lea    (%rbx,%r13,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed51:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ed54:	jb     1f256 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd56>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ed5a:	cmp    %rax,%r13
   1ed5d:	ja     1f24a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd4a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed63:	mov    %rbp,%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ed66:	sub    %rbx,%rax
   1ed69:	cmp    %rax,%r15
   1ed6c:	ja     1f00c <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xb0c>
   1ed72:	mov    0x8(%rsp),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1ed77:	lea    (%rax,%r15,1),%rdi
add<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1ed7b:	mov    0x10(%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed80:	mov    %rbx,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ed83:	call   *%r12
   1ed86:	mov    0x20(%rsp),%r11
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:505
   1ed8b:	add    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1ed8e:	sub    %rbx,%r14
   1ed91:	jne    1ed40 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x840>
   1ed93:	mov    0x50(%rsp),%r13
   1ed98:	mov    0x68(%rsp),%rbx
   1ed9d:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
   1eda2:	mov    0x10(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eda7:	cmp    $0xffffffffffffffe0,%rdi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1edab:	jae    1f1df <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcdf>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1edb1:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1edb9:	mov    0x8(%rax),%rcx
   1edbd:	mov    0x28(%rsp),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1edc2:	movups (%rax),%xmm0
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1edc5:	movups 0x10(%rax),%xmm1
   1edc9:	movups %xmm1,0x10(%rcx,%rdi,1)
   1edce:	mov    %rcx,0x8(%rsp)
   1edd3:	movups %xmm0,(%rcx,%rdi,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1edd7:	sub    %rbx,%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1edda:	add    %rbx,%rax
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1eddd:	mov    %rax,0x28(%rsp)
   1ede2:	jmp    1ebec <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x6ec>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:473
   1ede7:	lea    0x18(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1edeb:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1edee:	jb     1f2fe <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xdfe>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1edf4:	cmp    $0xffffffffffffffe8,%rsi
   1edf8:	jae    1f2f2 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xdf2>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1edfe:	add    $0xffffffffffffffe8,%rbp
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ee02:	cmp    %rbp,%r15
   1ee05:	ja     1f1ef <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcef>
   1ee0b:	mov    0xe0(%rsp),%rax
   1ee13:	mov    0x8(%rax),%rcx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ee17:	movups (%rcx,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ee1b:	mov    0x10(%rcx,%rsi,1),%rax
   1ee20:	mov    %rax,0x10(%rcx,%r15,1)
   1ee25:	mov    %rcx,0x8(%rsp)
   1ee2a:	movups %xmm0,(%rcx,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1ee2f:	add    %r14,%r15
   1ee32:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:476
   1ee37:	cmp    $0x10,%r14
   1ee3b:	ja     1ee90 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x990>
   1ee3d:	lea    0x10(%r15),%rax
   1ee41:	cmp    %rbp,%rax
   1ee44:	ja     1ee90 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x990>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:477
   1ee46:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ee4a:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ee4d:	jb     1f336 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe36>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ee53:	cmp    $0xfffffffffffffff0,%rsi
   1ee57:	jae    1f32a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe2a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ee5d:	add    $0xfffffffffffffff0,%rbp
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1ee61:	cmp    %rbp,%r15
   1ee64:	ja     1f218 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd18>
   1ee6a:	mov    0xe0(%rsp),%rax
   1ee72:	mov    0x8(%rax),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ee76:	movups (%rax,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1ee7a:	mov    %rax,0x8(%rsp)
   1ee7f:	movups %xmm0,(%rax,%r15,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1ee84:	add    %r14,%r15
   1ee87:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
   1ee8c:	nopl   0x0(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:479
   1ee90:	lea    (%r14,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ee94:	cmp    %rax,%rbp
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1ee97:	jb     1f2c6 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xdc6>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1ee9d:	cmp    %rax,%rsi
   1eea0:	ja     1f2ba <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xdba>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1eea6:	sub    %r14,%rbp
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1eea9:	cmp    %rbp,%r15
   1eeac:	ja     1f1b0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xcb0>
   1eeb2:	mov    0xe0(%rsp),%rax
   1eeba:	mov    0x8(%rax),%rax
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1eebe:	add    %rax,%rsi
add<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1eec1:	mov    %rax,0x8(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1eec6:	lea    (%rax,%r15,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1eeca:	mov    %r14,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1eecd:	call   *%rcx
   1eecf:	mov    0x20(%rsp),%r11
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1eed4:	add    %r14,%r15
   1eed7:	jmp    1e580 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x80>
   1eedc:	mov    0x10(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eee1:	cmp    $0xfffffffffffffff8,%rdi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1eee5:	jae    1f208 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd08>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eeeb:	mov    0xe0(%rsp),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1eef3:	mov    0x8(%rax),%rdx
   1eef7:	mov    0x28(%rsp),%rcx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eefc:	mov    (%rcx),%rax
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1eeff:	mov    %rdx,0x8(%rsp)
   1ef04:	mov    %rax,(%rdx,%rdi,1)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1ef08:	sub    %rbx,%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ef0b:	add    %rbx,%rcx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1ef0e:	mov    %rcx,0x28(%rsp)
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1ef13:	jmp    1ebec <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x6ec>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1ef18:	mov    $0x1,%ecx
   1ef1d:	mov    $0x1,%r8d
   1ef23:	mov    0xe0(%rsp),%rdi
   1ef2b:	mov    %rbp,%rsi
   1ef2e:	mov    %r15,%rdx
   1ef31:	call   26560 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1ef36:	mov    0xe0(%rsp),%rax
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1ef3e:	mov    0x10(%rax),%rbp
   1ef42:	jmp    1eaea <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0x5ea>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ef47:	mov    0x10(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:509
   1ef4c:	mov    %rax,%rbx
   1ef4f:	add    %r13,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ef52:	jb     1f19a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc9a>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1ef58:	cmp    %rbp,%rbx
   1ef5b:	ja     1f19a <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xc9a>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ef61:	mov    0x8(%rsp),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ef66:	add    %rax,%rdi
get_offset_len_mut_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1ef69:	mov    0x28(%rsp),%rsi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ef6e:	mov    %r13,%rdx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1ef71:	call   *0x49a99(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1ef77:	xor    %eax,%eax
   1ef79:	jmp    1efc0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xac0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1ef7b:	lea    -0x13585(%rip),%rsi        # b9fd <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1ef82:	mov    $0x18,%edx
   1ef87:	jmp    1efad <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xaad>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1ef89:	lea    -0x12049(%rip),%rsi        # cf47 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.11502846294190540699>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1ef90:	mov    $0xd,%edx
   1ef95:	jmp    1efad <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xaad>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1ef97:	mov    $0x1,%eax
   1ef9c:	mov    %r14,%rbx
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1ef9f:	jmp    1efc0 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xac0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1efa1:	lea    -0x13593(%rip),%rsi        # ba15 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1efa8:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1efad:	mov    $0x15,%edi
   1efb2:	call   *0x49be8(%rip)        # 68ba0 <_DYNAMIC+0x460>
   1efb8:	mov    %rax,%rbx
   1efbb:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:511
   1efc0:	mov    %rbx,%rdx
   1efc3:	add    $0x98,%rsp
   1efca:	pop    %rbx
   1efcb:	pop    %r12
   1efcd:	pop    %r13
   1efcf:	pop    %r14
   1efd1:	pop    %r15
   1efd3:	pop    %rbp
   1efd4:	ret
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1efd5:	lea    0x476a4(%rip),%rdi        # 66680 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x798>
unwrap<(&[u8; 2], &[[u8; 2]])>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1efdc:	call   *0x49a1e(%rip)        # 68a00 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1efe2:	lea    0x475ef(%rip),%rcx        # 665d8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x6f0>
   1efe9:	mov    %rbx,%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1efec:	mov    %rbp,%rsi
   1efef:	mov    %rbp,%rdx
   1eff2:	call   *0x49b58(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1eff8:	lea    0x47549(%rip),%rcx        # 66548 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x660>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1efff:	mov    $0x10,%esi
   1f004:	xor    %edi,%edi
   1f006:	call   *0x49b44(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f00c:	lea    -0x1362b(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f013:	lea    0x47486(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1f01a:	mov    $0x2b,%esi
   1f01f:	call   *0x49b83(%rip)        # 68ba8 <_DYNAMIC+0x468>
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:545
   1f025:	lea    0x47594(%rip),%rcx        # 665c0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x6d8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f02c:	mov    %rsi,%rdi
   1f02f:	mov    %rbp,%rsi
   1f032:	mov    %rbp,%rdx
   1f035:	call   *0x49b15(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f03b:	lea    -0x1365a(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f042:	lea    0x47517(%rip),%rdx        # 66560 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x678>
   1f049:	mov    $0x2b,%esi
   1f04e:	call   *0x49b54(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f054:	lea    0x4754d(%rip),%rdi        # 665a8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x6c0>
unwrap<&[u8; 32]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f05b:	call   *0x4999f(%rip)        # 68a00 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f061:	lea    0x47528(%rip),%rcx        # 66590 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x6a8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f068:	mov    %rax,%rdi
   1f06b:	mov    %rbp,%rsi
   1f06e:	mov    %rbp,%rdx
   1f071:	call   *0x49ad9(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f077:	lea    0x474fa(%rip),%rcx        # 66578 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x690>
   1f07e:	mov    $0x20,%esi
   1f083:	xor    %edi,%edi
   1f085:	call   *0x49ac5(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f08b:	lea    0x47606(%rip),%rdi        # 66698 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x7b0>
unwrap<(&[[u8; 2]; 2], &[[u8; 2]])>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f092:	call   *0x49968(%rip)        # 68a00 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f098:	lea    0x47719(%rip),%rcx        # 667b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x8d0>
   1f09f:	mov    0x10(%rsp),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f0a4:	mov    %rbp,%rsi
   1f0a7:	mov    %rbp,%rdx
   1f0aa:	call   *0x49aa0(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0b0:	lea    0x475f9(%rip),%rcx        # 666b0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x7c8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f0b7:	mov    $0x10,%esi
   1f0bc:	xor    %edi,%edi
   1f0be:	call   *0x49a8c(%rip)        # 68b50 <_DYNAMIC+0x410>
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:545
   1f0c4:	lea    0x476d5(%rip),%rcx        # 667a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x8b8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f0cb:	mov    %rsi,%rdi
   1f0ce:	mov    %rbp,%rsi
   1f0d1:	mov    %rbp,%rdx
   1f0d4:	call   *0x49a76(%rip)        # 68b50 <_DYNAMIC+0x410>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f0da:	lea    0x476a7(%rip),%rdi        # 66788 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x8a0>
unwrap<&[u8; 24]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f0e1:	call   *0x49919(%rip)        # 68a00 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f0e7:	lea    0x47682(%rip),%rcx        # 66770 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x888>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f0ee:	mov    %rax,%rdi
   1f0f1:	mov    %rbp,%rsi
   1f0f4:	mov    %rbp,%rdx
   1f0f7:	call   *0x49a53(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f0fd:	lea    0x475c4(%rip),%rcx        # 666c8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x7e0>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f104:	mov    $0x18,%esi
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f109:	xor    %edi,%edi
   1f10b:	call   *0x49a3f(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f111:	lea    0x47400(%rip),%rcx        # 66518 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f118:	mov    0x10(%rsp),%rdi
   1f11d:	mov    %r15,%rsi
   1f120:	mov    %rbp,%rdx
   1f123:	call   *0x49a27(%rip)        # 68b50 <_DYNAMIC+0x410>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f129:	lea    0x47628(%rip),%rcx        # 66758 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x870>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f130:	mov    %rbp,%rsi
   1f133:	mov    %rbp,%rdx
   1f136:	call   *0x49a14(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f13c:	lea    0x4759d(%rip),%rcx        # 666e0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x7f8>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f143:	mov    $0x10,%esi
   1f148:	xor    %edi,%edi
   1f14a:	call   *0x49a00(%rip)        # 68b50 <_DYNAMIC+0x410>
index<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:545
   1f150:	lea    0x475e9(%rip),%rcx        # 66740 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x858>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f157:	mov    %rbp,%rsi
   1f15a:	mov    %rbp,%rdx
   1f15d:	call   *0x499ed(%rip)        # 68b50 <_DYNAMIC+0x410>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f163:	lea    0x475be(%rip),%rdi        # 66728 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x840>
unwrap<&[u8; 24]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/option.rs:1016
   1f16a:	call   *0x49890(%rip)        # 68a00 <_DYNAMIC+0x2c0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:558
   1f170:	lea    0x47599(%rip),%rcx        # 66710 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x828>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f177:	mov    %rax,%rdi
   1f17a:	mov    %rbp,%rsi
   1f17d:	mov    %rbp,%rdx
   1f180:	call   *0x499ca(%rip)        # 68b50 <_DYNAMIC+0x410>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f186:	lea    0x4756b(%rip),%rcx        # 666f8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x810>
   1f18d:	mov    $0x18,%esi
   1f192:	xor    %edi,%edi
   1f194:	call   *0x499b6(%rip)        # 68b50 <_DYNAMIC+0x410>
   1f19a:	lea    0x4738f(%rip),%rcx        # 66530 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x648>
   1f1a1:	mov    %rax,%rdi
   1f1a4:	mov    %rbx,%rsi
   1f1a7:	mov    %rbp,%rdx
   1f1aa:	call   *0x499a0(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f1b0:	lea    -0x137cf(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f1b7:	lea    0x47312(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1f1be:	mov    $0x2b,%esi
   1f1c3:	call   *0x499df(%rip)        # 68ba8 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f1c9:	lea    0x472e8(%rip),%rcx        # 664b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5d0>
   1f1d0:	mov    %r15,%rdi
   1f1d3:	mov    %rdx,%rsi
   1f1d6:	mov    %rbp,%rdx
   1f1d9:	call   *0x49971(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f1df:	lea    0x4740a(%rip),%rcx        # 665f0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x708>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f1e6:	mov    %rbp,%rdx
   1f1e9:	call   *0x49961(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f1ef:	lea    -0x1380e(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f1f6:	lea    0x4740b(%rip),%rdx        # 66608 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x720>
   1f1fd:	mov    $0x2b,%esi
   1f202:	call   *0x499a0(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f208:	lea    0x47279(%rip),%rcx        # 66488 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f20f:	mov    %rbp,%rdx
   1f212:	call   *0x49938(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f218:	lea    -0x13837(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f21f:	lea    0x472c2(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1f226:	mov    $0x2b,%esi
   1f22b:	call   *0x49977(%rip)        # 68ba8 <_DYNAMIC+0x468>
   1f231:	lea    -0x13850(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f238:	lea    0x472c1(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1f23f:	mov    $0x2b,%esi
   1f244:	call   *0x4995e(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f24a:	mov    $0x1,%ecx
   1f24f:	mov    %rcx,0x18(%rsp)
   1f254:	jmp    1f259 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd59>
   1f256:	mov    %rax,%r13
   1f259:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f25e:	mov    %rcx,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f263:	mov    %r13,0x40(%rsp)
   1f268:	mov    %rax,0x48(%rsp)
   1f26d:	lea    0x4722c(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1f274:	lea    0x38(%rsp),%rdi
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f279:	mov    %rbp,%rsi
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f27c:	call   *0x4992e(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f282:	mov    $0x1,%eax
   1f287:	mov    %rax,0x18(%rsp)
   1f28c:	jmp    1f291 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xd91>
   1f28e:	mov    %rdx,%rsi
   1f291:	mov    0x18(%rsp),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f296:	mov    %rax,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f29b:	mov    %rsi,0x40(%rsp)
   1f2a0:	mov    %rdx,0x48(%rsp)
   1f2a5:	lea    0x472b4(%rip),%rdx        # 66560 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x678>
   1f2ac:	lea    0x38(%rsp),%rdi
   1f2b1:	mov    %rbp,%rsi
   1f2b4:	call   *0x498f6(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f2ba:	mov    $0x1,%ecx
   1f2bf:	mov    %rcx,0x18(%rsp)
   1f2c4:	jmp    1f2c9 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xdc9>
   1f2c6:	mov    %rax,%rsi
   1f2c9:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f2ce:	mov    %rcx,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f2d3:	mov    %rsi,0x40(%rsp)
   1f2d8:	mov    %rax,0x48(%rsp)
   1f2dd:	lea    0x471ec(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1f2e4:	lea    0x38(%rsp),%rdi
   1f2e9:	mov    %rbp,%rsi
   1f2ec:	call   *0x498be(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f2f2:	mov    $0x1,%ecx
   1f2f7:	mov    %rcx,0x18(%rsp)
   1f2fc:	jmp    1f301 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe01>
   1f2fe:	mov    %rax,%rsi
   1f301:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f306:	mov    %rcx,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f30b:	mov    %rsi,0x40(%rsp)
   1f310:	mov    %rax,0x48(%rsp)
   1f315:	lea    0x472ec(%rip),%rdx        # 66608 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x720>
   1f31c:	lea    0x38(%rsp),%rdi
   1f321:	mov    %rbp,%rsi
   1f324:	call   *0x49886(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f32a:	mov    $0x1,%ecx
   1f32f:	mov    %rcx,0x18(%rsp)
   1f334:	jmp    1f339 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe39>
   1f336:	mov    %rax,%rsi
   1f339:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f33e:	mov    %rcx,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f343:	mov    %rsi,0x40(%rsp)
   1f348:	mov    %rax,0x48(%rsp)
   1f34d:	lea    0x47194(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1f354:	lea    0x38(%rsp),%rdi
   1f359:	mov    %rbp,%rsi
   1f35c:	call   *0x4984e(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f362:	mov    $0x1,%ecx
   1f367:	mov    %rcx,0x18(%rsp)
   1f36c:	jmp    1f371 <zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>+0xe71>
   1f36e:	mov    %rax,%rsi
   1f371:	mov    0x18(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f376:	mov    %rcx,0x38(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f37b:	mov    %rsi,0x40(%rsp)
   1f380:	mov    %rax,0x48(%rsp)
   1f385:	lea    0x47174(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1f38c:	lea    0x38(%rsp),%rdi
   1f391:	mov    %rbp,%rsi
   1f394:	call   *0x49816(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<15, zxc_codec::block::Spl16>:
   1f39a:	int3
   1f39b:	int3
   1f39c:	int3
   1f39d:	int3
   1f39e:	int3
   1f39f:	int3

000000000001f3a0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>>:
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:372
   1f3a0:	push   %rbp
   1f3a1:	push   %r15
   1f3a3:	push   %r14
   1f3a5:	push   %r13
   1f3a7:	push   %r12
   1f3a9:	push   %rbx
   1f3aa:	sub    $0x68,%rsp
   1f3ae:	mov    %rcx,%rbp
   1f3b1:	mov    %rdx,0x20(%rsp)
   1f3b6:	mov    0xb8(%rsp),%r13
   1f3be:	mov    %r8,0x58(%rsp)
   1f3c3:	mov    %r9,0x60(%rsp)
   1f3c8:	mov    %rsi,0x48(%rsp)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/non_null.rs:1709
   1f3cd:	cmp    %rsi,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/iter/macros.rs:180
   1f3d0:	je     1f7cb <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x42b>
   1f3d6:	mov    %rdi,%r12
   1f3d9:	mov    0xa0(%rsp),%rax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:380
   1f3e1:	sub    %rbp,%rax
   1f3e4:	mov    %rax,0x40(%rsp)
   1f3e9:	movq   $0x0,0x10(%rsp)
   1f3f2:	xor    %r15d,%r15d
   1f3f5:	jmp    1f426 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x86>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f3f7:	movups (%rdi,%rsi,1),%xmm0
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f3fb:	movups %xmm0,(%rdi,%rbx,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:481
   1f3ff:	add    %rbx,%r12
   1f402:	mov    %r12,%r15
   1f405:	mov    0x50(%rsp),%r12
   1f40a:	add    $0x4,%r12
eq<[u8; 4]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/non_null.rs:1709
   1f40e:	cmp    0x48(%rsp),%r12
   1f413:	mov    0x18(%rsp),%rbp
   1f418:	mov    0xb8(%rsp),%r13
next<[u8; 4]>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/iter/macros.rs:180
   1f420:	je     1f7d2 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x432>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:240
   1f426:	movzwl (%r12),%edi
{closure#1}():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:240
   1f42b:	movzbl 0x2(%r12),%ebx
   1f431:	movzbl 0x3(%r12),%r14d
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:427
   1f437:	cmp    $0xff,%r14
   1f43e:	mov    %rdi,0x18(%rsp)
   1f443:	jne    1f466 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0xc6>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1f445:	lea    0x58(%rsp),%rdi
   1f44a:	call   202c0 <zxc_codec::block::extra>
   1f44f:	mov    %rdx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f452:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f454:	jne    1f840 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:428
   1f45a:	add    $0xff,%r14
   1f461:	mov    0x18(%rsp),%rdi
   1f466:	mov    %r12,0x50(%rsp)
   1f46b:	mov    %edi,%eax
   1f46d:	shl    $0x10,%eax
   1f470:	shl    $0x8,%ebx
   1f473:	or     %eax,%ebx
   1f475:	shr    $0x8,%ebx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/convert/num.rs:154
   1f478:	movzbl %bl,%r12d
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:430
   1f47c:	add    $0x5,%r12
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:431
   1f480:	cmp    $0x104,%r12
   1f487:	mov    0xa0(%rsp),%rbx
   1f48f:	jne    1f4b2 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x112>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1f491:	lea    0x58(%rsp),%rdi
   1f496:	call   202c0 <zxc_codec::block::extra>
   1f49b:	mov    %rdx,%r12
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f49e:	test   $0x1,%al
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f4a0:	jne    1f81c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x47c>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:432
   1f4a6:	add    $0x104,%r12
   1f4ad:	mov    0x18(%rsp),%rdi
   1f4b2:	mov    0x40(%rsp),%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:435
   1f4b7:	sub    %r12,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:74
   1f4ba:	jb     1f800 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x460>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:439
   1f4c0:	mov    %rbx,%rax
   1f4c3:	mov    %rcx,0x40(%rsp)
   1f4c8:	sub    %rcx,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f4cb:	mov    0x10(%r13),%r9
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:440
   1f4cf:	cmp    %r9,%rax
   1f4d2:	jbe    1f53c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x19c>
   1f4d4:	mov    %rbx,%rcx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:441
   1f4d7:	lea    (%r9,%r9,1),%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1f4db:	cmp    %rbx,%rax
max():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2295
   1f4de:	cmova  %rax,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f4e2:	cmp    %rcx,%rbx
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f4e5:	cmovae %rcx,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1f4e9:	cmp    %r9,%rcx
resize<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3698
   1f4ec:	jbe    1f530 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x190>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3699
   1f4ee:	sub    %r9,%rbx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:640
   1f4f1:	mov    0x0(%r13),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:2784
   1f4f5:	sub    %r9,%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:795
   1f4f8:	cmp    %rax,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:695
   1f4fb:	ja     1f7a9 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x409>
   1f501:	mov    %r9,0x8(%rsp)
spec_extend_with<u8, alloc::alloc::Global>():
   1f506:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f50a:	add    %r9,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f50d:	xor    %esi,%esi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f50f:	mov    %rbx,%rdx
   1f512:	call   *0x49678(%rip)        # 68b90 <memset@GLIBC_2.2.5>
spec_extend_with<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/spec_extend_with.rs:100
   1f518:	add    0x8(%rsp),%rbx
   1f51d:	mov    0x18(%rsp),%rdi
   1f522:	jmp    1f535 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x195>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f524:	data16 data16 cs nopw 0x0(%rax,%rax,1)
truncate<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1748
   1f530:	cmp    %r9,%rbx
   1f533:	jae    1f53c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x19c>
resize<u8, alloc::alloc::Global>():
   1f535:	mov    %rbx,0x10(%r13)
   1f539:	mov    %rbx,%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:443
   1f53c:	lea    (%r14,%r15,1),%rbx
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1f540:	cmp    $0x8,%r14
   1f544:	mov    %r9,0x8(%rsp)
   1f549:	ja     1f563 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x1c3>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:456
   1f54b:	lea    0x8(%r15),%rsi
   1f54f:	cmp    %r9,%rsi
   1f552:	ja     1f55e <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x1be>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1f554:	cmp    $0x8,%rbp
first_chunk<u8, 8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:330
   1f558:	jae    1f74e <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x3ae>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:461
   1f55e:	test   %r14,%r14
   1f561:	je     1f5b6 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x216>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1f563:	sub    %r14,%rbp
split_at_checked<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:2165
   1f566:	jb     1f80e <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x46e>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f56c:	cmp    %r15,%rbx
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f56f:	jb     1f870 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4d0>
   1f575:	cmp    %r9,%rbx
   1f578:	ja     1f870 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4d0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f57e:	mov    0x20(%rsp),%rsi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/const_ptr.rs:879
   1f583:	lea    (%rsi,%r14,1),%r13
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f587:	mov    0xb8(%rsp),%rax
get_offset_len_mut_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f58f:	add    0x8(%rax),%r15
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f593:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f596:	mov    %r14,%rdx
   1f599:	call   *0x49471(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1f59f:	mov    0x18(%rsp),%rdi
   1f5a4:	mov    0x8(%rsp),%r9
   1f5a9:	mov    %r13,0x20(%rsp)
   1f5ae:	mov    0xb8(%rsp),%r13
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f5b6:	inc    %edi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:466
   1f5b8:	mov    %rbx,%rsi
   1f5bb:	sub    %rdi,%rsi
   1f5be:	mov    %rbp,0x18(%rsp)
   1f5c3:	jb     1f620 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x280>
   1f5c5:	cmp    %rdi,%r12
   1f5c8:	ja     1f620 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x280>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1f5ca:	cmp    $0x9,%r12
   1f5ce:	jae    1f700 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x360>
   1f5d4:	lea    0x8(%rbx),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f5d8:	mov    0x8(%r13),%rdi
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1f5dc:	cmp    %r9,%rax
   1f5df:	ja     1f70a <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x36a>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:475
   1f5e5:	lea    0x8(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f5e9:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f5ec:	jb     1f9c0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x620>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f5f2:	cmp    $0xfffffffffffffff8,%rsi
   1f5f6:	jae    1f9b4 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x614>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f5fc:	lea    -0x8(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f600:	cmp    %rax,%rbx
   1f603:	ja     1f8de <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x53e>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f609:	mov    (%rdi,%rsi,1),%rax
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f60d:	mov    %rax,(%rdi,%rbx,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:474
   1f611:	jmp    1f3ff <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5f>
   1f616:	cs nopw 0x0(%rax,%rax,1)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:484
   1f620:	cmp    %rdi,%rbx
   1f623:	jae    1f680 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x2e0>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:487
   1f625:	mov    %rdi,%r14
   1f628:	sub    %rbx,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f62b:	mov    0xb0(%rsp),%rsi
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f633:	sub    %r14,%rsi
   1f636:	jb     1f826 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x486>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f63c:	cmp    %r14,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f63f:	cmovb  %r12,%r14
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:493
   1f643:	lea    (%r14,%rbx,1),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1f647:	cmp    %r9,%r15
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:422
   1f64a:	ja     1f89f <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4ff>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f650:	mov    0x8(%r13),%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f654:	add    %rbp,%rbx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f657:	add    0xa8(%rsp),%rsi
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f65f:	mov    %rdi,%r13
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f662:	mov    %rbx,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f665:	mov    %r14,%rdx
   1f668:	call   *0x493a2(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1f66e:	mov    %r13,%rdi
   1f671:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:496
   1f676:	sub    %r14,%r12
   1f679:	jne    1f690 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x2f0>
   1f67b:	jmp    1f405 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1f680:	test   %r12,%r12
   1f683:	je     1f7a1 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x401>
   1f689:	mov    0x8(%r13),%rbp
   1f68d:	mov    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:500
   1f690:	mov    %r15,%r13
   1f693:	sub    %rdi,%r13
   1f696:	mov    %rbp,%rbx
   1f699:	add    %r13,%rbx
   1f69c:	nopl   0x0(%rax)
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:503
   1f6a0:	mov    %r15,%r14
   1f6a3:	sub    %r13,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f6a6:	cmp    %r14,%r12
min():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/cmp.rs:2290
   1f6a9:	cmovb  %r12,%r14
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:504
   1f6ad:	lea    (%r14,%r13,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f6b1:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f6b4:	jb     1f917 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x577>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f6ba:	cmp    %rax,%r13
   1f6bd:	ja     1f910 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x570>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f6c3:	sub    %r14,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f6c6:	cmp    %r9,%r15
   1f6c9:	ja     1f857 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4b7>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f6cf:	lea    (%r15,%rbp,1),%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f6d3:	mov    %rbx,%rsi
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f6d6:	mov    %r14,%rdx
   1f6d9:	call   *0x494b9(%rip)        # 68b98 <memmove@GLIBC_2.2.5>
   1f6df:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:505
   1f6e4:	add    %r14,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1f6e7:	sub    %r14,%r12
   1f6ea:	jne    1f6a0 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x300>
   1f6ec:	jmp    1f405 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
non_null<alloc::alloc::Global, u8>():
   1f6f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f700:	mov    0x8(%r13),%rdi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:476
   1f704:	cmp    $0x11,%r12
   1f708:	jae    1f713 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x373>
   1f70a:	lea    0x10(%rbx),%rax
   1f70e:	cmp    %r9,%rax
   1f711:	jbe    1f778 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x3d8>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:479
   1f713:	lea    (%r12,%rsi,1),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f717:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f71a:	jb     1f94c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5ac>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f720:	cmp    %rax,%rsi
   1f723:	ja     1f940 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5a0>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f729:	sub    %r12,%r9
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f72c:	cmp    %r9,%rbx
   1f72f:	ja     1f886 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4e6>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mut_ptr.rs:978
   1f735:	add    %rdi,%rsi
   1f738:	add    %rbx,%rdi
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f73b:	mov    %r12,%rdx
copy<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:670
   1f73e:	call   *0x49454(%rip)        # 68b98 <memmove@GLIBC_2.2.5>
   1f744:	mov    0x8(%rsp),%r9
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:476
   1f749:	jmp    1f3ff <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5f>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f74e:	cmp    $0xfffffffffffffff8,%r15
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f752:	jae    1f8cb <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x52b>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f758:	mov    0x8(%r13),%rax
non_null<alloc::alloc::Global, u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:635
   1f75c:	mov    0x20(%rsp),%rdx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f761:	mov    (%rdx),%rcx
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f764:	mov    %rcx,(%rax,%r15,1)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:549
   1f768:	sub    %r14,%rbp
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f76b:	add    %r14,%rdx
get_offset_len_noubcheck<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:90
   1f76e:	mov    %rdx,0x20(%rsp)
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:455
   1f773:	jmp    1f5b6 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x216>
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:477
   1f778:	lea    0x10(%rsi),%rax
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f77c:	cmp    %rax,%r9
try_into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:995
   1f77f:	jb     1f986 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5e6>
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1008
   1f785:	cmp    $0xfffffffffffffff0,%rsi
   1f789:	jae    1f97a <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5da>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f78f:	lea    -0x10(%r9),%rax
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f793:	cmp    %rax,%rbx
   1f796:	jbe    1f3f7 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x57>
   1f79c:	jmp    1f8f7 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x557>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f7a1:	mov    %rbx,%r15
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:502
   1f7a4:	jmp    1f405 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x65>
reserve<alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/raw_vec/mod.rs:699
   1f7a9:	mov    $0x1,%ecx
   1f7ae:	mov    $0x1,%r8d
   1f7b4:	mov    %r13,%rdi
   1f7b7:	mov    %r9,%rsi
   1f7ba:	mov    %rbx,%rdx
   1f7bd:	call   26560 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f7c2:	mov    0x10(%r13),%r9
len<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:3166
   1f7c6:	jmp    1f501 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x161>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1f7cb:	mov    0x10(%r13),%r9
as_mut_slice<u8, alloc::alloc::Global>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/alloc/src/vec/mod.rs:1829
   1f7cf:	xor    %r15d,%r15d
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:509
   1f7d2:	mov    %r15,%r14
   1f7d5:	add    %rbp,%r14
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f7d8:	jb     1f8b5 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x515>
checked_sub():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/num/uint_macros.rs:1192
   1f7de:	cmp    %r9,%r14
   1f7e1:	ja     1f8b5 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x515>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:102
   1f7e7:	add    0x8(%r13),%r15
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f7eb:	mov    %r15,%rdi
copy_nonoverlapping<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/ptr/mod.rs:579
   1f7ee:	mov    0x20(%rsp),%rsi
   1f7f3:	mov    %rbp,%rdx
   1f7f6:	call   *0x49214(%rip)        # 68a10 <memcpy@GLIBC_2.14>
   1f7fc:	xor    %eax,%eax
   1f7fe:	jmp    1f845 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a5>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f800:	lea    -0x13e0a(%rip),%rsi        # b9fd <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdad>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f807:	mov    $0x18,%edx
   1f80c:	jmp    1f832 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x492>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f80e:	lea    -0x128ce(%rip),%rsi        # cf47 <anon.7e78939d756a72dec40ff51361ecc601.3.llvm.11502846294190540699>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f815:	mov    $0xd,%edx
   1f81a:	jmp    1f832 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x492>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f81c:	mov    $0x1,%eax
   1f821:	mov    %r12,%r14
branch<usize, core::io::error::Error>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/result.rs:2182
   1f824:	jmp    1f845 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x4a5>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f826:	lea    -0x13e18(%rip),%rsi        # ba15 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xdc5>
bad():
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/lib.rs:71
   1f82d:	mov    $0x1d,%edx
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f832:	mov    $0x15,%edi
   1f837:	call   *0x49363(%rip)        # 68ba0 <_DYNAMIC+0x460>
   1f83d:	mov    %rax,%r14
   1f840:	mov    $0x1,%eax
/home/rektide/src/zxc-rs/.test-agent/decode-next-sol/src-copy/crates/codec/src/block.rs:511
   1f845:	mov    %r14,%rdx
   1f848:	add    $0x68,%rsp
   1f84c:	pop    %rbx
   1f84d:	pop    %r12
   1f84f:	pop    %r13
   1f851:	pop    %r14
   1f853:	pop    %r15
   1f855:	pop    %rbp
   1f856:	ret
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f857:	lea    -0x13e76(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f85e:	lea    0x46c3b(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1f865:	mov    $0x2b,%esi
   1f86a:	call   *0x49338(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f870:	lea    0x46ca1(%rip),%rcx        # 66518 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x630>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f877:	mov    %r15,%rdi
   1f87a:	mov    %rbx,%rsi
   1f87d:	mov    %r9,%rdx
   1f880:	call   *0x492ca(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f886:	lea    -0x13ea5(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f88d:	lea    0x46c3c(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1f894:	mov    $0x2b,%esi
   1f899:	call   *0x49309(%rip)        # 68ba8 <_DYNAMIC+0x468>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f89f:	lea    0x46c12(%rip),%rcx        # 664b8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5d0>
   1f8a6:	mov    %rbx,%rdi
   1f8a9:	mov    %r15,%rsi
   1f8ac:	mov    %r9,%rdx
   1f8af:	call   *0x4929b(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f8b5:	lea    0x46c74(%rip),%rcx        # 66530 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x648>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f8bc:	mov    %r15,%rdi
   1f8bf:	mov    %r14,%rsi
   1f8c2:	mov    %r9,%rdx
   1f8c5:	call   *0x49285(%rip)        # 68b50 <_DYNAMIC+0x410>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f8cb:	lea    0x46bb6(%rip),%rcx        # 66488 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5a0>
index_mut<u8>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:427
   1f8d2:	mov    %r15,%rdi
   1f8d5:	mov    %r9,%rdx
   1f8d8:	call   *0x49272(%rip)        # 68b50 <_DYNAMIC+0x410>
copy_within<u8, core::ops::range::Range<usize>>():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/mod.rs:4376
   1f8de:	lea    -0x13efd(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f8e5:	lea    0x46c14(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1f8ec:	mov    $0x2b,%esi
   1f8f1:	call   *0x492b1(%rip)        # 68ba8 <_DYNAMIC+0x468>
   1f8f7:	lea    -0x13f16(%rip),%rdi        # b9e8 <anon.0398ca8057284f2fe2f5aaf8520bfa64.0.llvm.17792033487855822839+0xd98>
   1f8fe:	lea    0x46be3(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1f905:	mov    $0x2b,%esi
   1f90a:	call   *0x49298(%rip)        # 68ba8 <_DYNAMIC+0x468>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f910:	mov    $0x1,%ecx
   1f915:	jmp    1f91c <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x57c>
   1f917:	mov    %rax,%r13
   1f91a:	xor    %ecx,%ecx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f91c:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f921:	mov    %r13,0x30(%rsp)
   1f926:	mov    %rax,0x38(%rsp)
   1f92b:	lea    0x46b6e(%rip),%rdx        # 664a0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5b8>
   1f932:	lea    0x28(%rsp),%rdi
   1f937:	mov    %r9,%rsi
   1f93a:	call   *0x49270(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f940:	mov    $0x1,%ecx
   1f945:	mov    %rcx,0x10(%rsp)
   1f94a:	jmp    1f94f <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5af>
   1f94c:	mov    %rax,%rsi
   1f94f:	mov    0x10(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f954:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f959:	mov    %rsi,0x30(%rsp)
   1f95e:	mov    %rax,0x38(%rsp)
   1f963:	lea    0x46b66(%rip),%rdx        # 664d0 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x5e8>
   1f96a:	lea    0x28(%rsp),%rdi
   1f96f:	mov    0x8(%rsp),%rsi
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f974:	call   *0x49236(%rip)        # 68bb0 <_DYNAMIC+0x470>
   1f97a:	mov    $0x1,%ecx
   1f97f:	mov    %rcx,0x10(%rsp)
   1f984:	jmp    1f989 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x5e9>
   1f986:	mov    %rax,%rsi
   1f989:	mov    0x10(%rsp),%rcx
   1f98e:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f993:	mov    %rsi,0x30(%rsp)
   1f998:	mov    %rax,0x38(%rsp)
   1f99d:	lea    0x46b44(%rip),%rdx        # 664e8 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x600>
   1f9a4:	lea    0x28(%rsp),%rdi
   1f9a9:	mov    0x8(%rsp),%rsi
   1f9ae:	call   *0x491fc(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f9b4:	mov    $0x1,%ecx
   1f9b9:	mov    %rcx,0x10(%rsp)
   1f9be:	jmp    1f9c3 <zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>+0x623>
   1f9c0:	mov    %rax,%rsi
   1f9c3:	mov    0x10(%rsp),%rcx
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f9c8:	mov    %rcx,0x28(%rsp)
into_slice_range():
/rustc/bdf712ee87c22a2b5c60db2e1af8a63e3cfd1a2e/library/core/src/slice/index.rs:1030
   1f9cd:	mov    %rsi,0x30(%rsp)
   1f9d2:	mov    %rax,0x38(%rsp)
   1f9d7:	lea    0x46b22(%rip),%rdx        # 66500 <anon.3498c658a873b49f75cecf4c7801683f.6.llvm.15397759494957552672+0x618>
   1f9de:	lea    0x28(%rsp),%rdi
   1f9e3:	mov    0x8(%rsp),%rsi
   1f9e8:	call   *0x491c2(%rip)        # 68bb0 <_DYNAMIC+0x470>
zxc_codec::block::reconstruct::<255, zxc_codec::block::Scalar<core::iter::adapters::map::Map<core::slice::iter::Iter<[u8; 4]>, zxc_codec::block::unpack_with_sections::{closure#1}>>>:
   1f9ee:	int3
   1f9ef:	int3

