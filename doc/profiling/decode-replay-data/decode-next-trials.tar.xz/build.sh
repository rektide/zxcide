#!/usr/bin/env bash
# Run from the repository root. Every variant starts from the same pinned tree.
set -euxo pipefail
pin=dac698f924ecbe452432425e9047f61b6e118065
root=$PWD
run=$(realpath "$(dirname "$0")")
data=$root/doc/profiling/decode-replay-data
label=$1
src=$run/src-$label
mkdir "$src"
git archive "$pin" | tar -x -C "$src"
cd "$src"
export CARGO_TARGET_DIR="$run/cargo"
export TMPDIR="$run/tmp"
mkdir -p "$TMPDIR"
case "$label" in
    base) ;;
    copy|bucket|census) patch -p1 < "$run/$label.patch" ;;
    *) exit 2 ;;
esac
rustc -Vv
cargo -V
export CARGO_ENCODED_RUSTFLAGS=''
if [[ "$label" != census ]]; then
    cargo build --release --locked -p zxc-cli
    cp "$CARGO_TARGET_DIR/release/zxc" "$run/cli-$label"
fi
mkdir -p crates/codec/src/bin
sed 's/h\[0\] == 1 \&\& view.len() >= 16 \&\& view\[11\] == 0/h[0] == 1 \&\& view.len() >= 16/;s@ // SPL16$@ // SPL16 or SPL8@' \
    "$data/replay.rs" > crates/codec/src/bin/replay.rs
cat "$data/section-entry.rs" >> crates/codec/src/block.rs
printf '\n#[doc(hidden)]\npub use block::replay_huf;\n' >> crates/codec/src/lib.rs
export CARGO_ENCODED_RUSTFLAGS=$'--cfg\x1freplay_perf\x1f-Cdebuginfo=line-tables-only'
export CARGO_PROFILE_RELEASE_STRIP=none
cargo build --release --locked -p zxc-codec --features merge-simd --bin replay
cp "$CARGO_TARGET_DIR/release/replay" "$run/replay-$label"
sha256sum "$run/replay-$label"
if [[ "$label" != census ]]; then sha256sum "$run/cli-$label"; fi
