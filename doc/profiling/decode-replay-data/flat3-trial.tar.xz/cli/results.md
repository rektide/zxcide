# Paired fixed-archive decode

| Case | Workers | Compare | Baseline MB/s (S1 / S2) | Other MB/s (S1 / S2) | Paired wall Δ [95% CI] | Paired CPU Δ | Peak RSS MiB, median base → other |
| --- | ---: | --- | ---: | ---: | --- | --- | --- |
| single | 8 | base → trial | 7,534 / 5,285 | 7,783 / 5,013 | -4.7% [-6.2,+5.3] / -2.3% [-8.9,+19.3] | +1.7% / +0.4% | 23.7 → 23.7 / 23.7 → 23.7 |
| sao | 8 | base → trial | 1,320 / 972 | 1,136 / 944 | +5.6% [-18.6,+16.1] / +6.1% [-11.7,+17.1] | +1.3% / -3.3% | 23.7 → 23.7 / 23.7 → 23.7 |
