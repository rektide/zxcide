#!/usr/bin/env python3
"""Select the two Rust builds and fixtures in the existing measurement drivers."""
from pathlib import Path
import sys

mode = sys.argv.pop(1)
if mode == 'reduce':
    path = Path('doc/profiling/decode-replay-data/reduce.py')
    changes = [("('c', 'rust', 'rust-native')", "('base', 'candidate')"),
               ("('c', 'rust-native')", "('candidate',)"),
               ("/ r['rust'][k]", "/ r['base'][k]"), ('{label}/rust:', '{label}/base:')]
elif mode == 'perf':
    path = Path('doc/profiling/decode-replay-data/perf.py')
    changes = [("LABELS = ('c', 'rust', 'rust-native')", "LABELS = ('base', 'candidate')"),
               ('ready[0] == ready[1] == ready[2]', 'ready[0] == ready[1]'),
               ('else list(REPEATS)', "else ['single', 'sao']")]
elif mode == 'cli':
    path = Path('doc/profiling/decode-pool-data/bench.py')
    changes = [('def invoke(label, workers, name):', '''cases = {k: [f'{k}.zxc'] for k in ('single', 'sao')}
comparisons = [(k, 8, 'base', 'trial') for k in cases]
def invoke(label, workers, name):'''),
               ('m["plain"]["bytes"]*1000', 'archives[cases[case][0]][2]*1000')]
else:
    raise ValueError(mode)
src = path.read_text()
for old, new in changes:
    assert src.count(old) == 1
    src = src.replace(old, new)
exec(compile(src, str(path), 'exec'), {'__name__': '__main__', '__file__': str(path.resolve())})
