# Width-three trial

Session `ses_df9f765f0ffel0TKk8pDiPlkN2`. Shared scratch source path for both builds; no working-tree edits in binaries. Keep gate: long literal paired cycles/symbol median at least 3% lower, and long checked cycles/B or eight-worker elapsed at least 1% lower, qualifying paired intervals below zero, no clear control regression or bounds/validation cost. Fixed 24 replay pairs per case and two CLI series of 12 pairs. Pin CPU 3 for replay, CPUs 0-7 for eight workers, repository perf lock throughout timing. Use `single` and lower-width-three-exposure `sao`.
