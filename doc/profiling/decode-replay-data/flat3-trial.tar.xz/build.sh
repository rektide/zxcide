#!/usr/bin/env bash
set -euxo pipefail
here=$(realpath doc/profiling/decode-replay-data)
out=$(realpath "$(dirname "$0")")
label=$1
rs=$out/rs
pin=09c0c9284cbebde06c53733f01827ff60c996efb
mkdir -p "$rs"
git archive "$pin" | tar -x -C "$rs"
if [[ $label == candidate ]]; then cp "$2" "$rs/crates/codec/src/entropy/flat.rs"; fi
cd "$rs"
export CARGO_TARGET_DIR=$out/cargo
export CARGO_ENCODED_RUSTFLAGS=''
if [[ ${NATIVE:-0} == 0 ]]; then
    cargo build --locked --release -p zxc-cli
    cp "$CARGO_TARGET_DIR/release/zxc" "$out/cli-$label"
fi
mkdir -p crates/codec/src/bin
cp "$here/replay.rs" crates/codec/src/bin/replay.rs
cat "$here/section-entry.rs" >> crates/codec/src/block.rs
printf '\n#[doc(hidden)]\npub use block::replay_huf;\n' >> crates/codec/src/lib.rs
export CARGO_ENCODED_RUSTFLAGS=$'--cfg\x1freplay_perf\x1f-Cdebuginfo=line-tables-only'
export CARGO_PROFILE_RELEASE_STRIP=none
if [[ ${NATIVE:-0} == 1 ]]; then
    CARGO_ENCODED_RUSTFLAGS+=$'\x1f-Ctarget-cpu=native'
    out=$out/native
    mkdir -p "$out"
fi
cargo build --release --locked -p zxc-codec --features merge-simd --bin replay
cp "$CARGO_TARGET_DIR/release/replay" "$out/replay-$label"
