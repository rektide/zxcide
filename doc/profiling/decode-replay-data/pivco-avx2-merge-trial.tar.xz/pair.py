#!/usr/bin/env python3
"""Select paired binaries, fixed archives and controls in the existing drivers."""
from pathlib import Path
import sys


mode = sys.argv.pop(1)
if mode == 'perf':
    path = Path('doc/profiling/decode-replay-data/perf.py')
    scalar = '--scalar' in sys.argv
    if scalar:
        sys.argv.remove('--scalar')
    labels = "('scalar-base', 'scalar-trial')" if scalar else "('base', 'trial')"
    changes = [("LABELS = ('c', 'rust', 'rust-native')", f'LABELS = {labels}'),
               ('ready[0] == ready[1] == ready[2]', 'ready[0] == ready[1]'),
               ('else list(REPEATS)', "else ['single', 'sao']"),
               ("(name == 'single-block' or not name.endswith('-block'))", "name == 'single-lit'"),
               ('six balanced rounds per cycle', 'two balanced rounds per cycle')]
elif mode == 'reduce':
    path = Path('doc/profiling/decode-replay-data/reduce.py')
    scalar = '--scalar' in sys.argv
    if scalar:
        sys.argv.remove('--scalar')
    base, trial = ('scalar-base', 'scalar-trial') if scalar else ('base', 'trial')
    changes = [("('c', 'rust', 'rust-native')", repr((base, trial))),
               ("('c', 'rust-native')", repr((trial,))),
               ("/ r['rust'][k]", f'/ r[{base!r}][k]'), ('{label}/rust:', f'{{label}}/{base}:')]
elif mode == 'cli':
    path = Path('doc/profiling/decode-pool-data/bench.py')
    changes = [('def invoke(label, workers, name):', '''
bins.update({f'scalar-{k}': p.with_name(f'cli-scalar-{k}') for k, p in (('base', a.baseline), ('trial', a.candidate))})
cases = {k: [f'{k}.zxc'] for k in ('single', 'sao')}
comparisons = [('single', w, 'base', 'trial') for w in (8, 1)]
comparisons.extend([('single', 8, 'base', 'c'), ('sao', 8, 'base', 'trial')])
comparisons.extend([(k, 8, 'scalar-base', 'scalar-trial') for k in cases])
def invoke(label, workers, name):'''),
               ('m["plain"]["bytes"]*1000', 'archives[cases[case][0]][2]*1000')]
else:
    raise ValueError(mode)

src = path.read_text()
for old, new in changes:
    assert src.count(old) == 1, old
    src = src.replace(old, new)
exec(compile(src, str(path), 'exec'), {'__name__': '__main__', '__file__': str(path.resolve())})
