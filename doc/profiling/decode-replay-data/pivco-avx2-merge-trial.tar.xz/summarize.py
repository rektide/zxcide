#!/usr/bin/env python3
"""Reduce fixed-work CLI paired ratios in throughput units and replay half checks."""

import json
from math import comb
from pathlib import Path
from statistics import median
import sys


def median_ci(xs):
    v = sorted(xs)
    n = len(v)
    k = max(i for i in range(n//2) if sum(comb(n, j) for j in range(i)) <= .025 * 2**n)
    return f'{median(v):+.2f}% [{v[k-1]:+.2f}, {v[n-k]:+.2f}]'


out = Path(sys.argv[1])
raw = json.loads((out / 'cli/raw.json').read_text())
for i, (archive, workers, a, b) in enumerate(raw['comparisons']):
    for j, series in enumerate(raw['series'], 1):
        pairs = [p for p in series['pairs'] if p['comparison'] == i and p['pass_index'] >= 0]
        assert sum(p['first'] for p in pairs) * 2 == len(pairs)
        samples = [p['results'] for p in pairs]
        print(f'{archive} W{workers} {a}:{b} S{j}: '
              f'{median_ci(100*(x[0]/y[0]-1) for x, y in samples)} throughput; '
              f'{median_ci(100*(y[1]/x[1]-1) for x, y in samples)} child CPU')

for path in ('counts/perf.json', 'scalar-counts/perf.json'):
    raw = json.loads((out / path).read_text())
    a, b = raw['binaries']
    for name, case in raw['cases'].items():
        rounds = case['rounds']
        assert all({next(iter(p)), next(iter(q))} == {a, b} for p, q in zip(rounds[::2], rounds[1::2]))
        delta = [100*(r[b]['cycles:u']/r[a]['cycles:u']-1) for r in rounds]
        mid = len(delta)//2
        print(f'{name} {a}:{b} cycle deltas by half: '
              f'{median_ci(delta[:mid])} / {median_ci(delta[mid:])}')
