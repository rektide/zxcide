#!/usr/bin/env bash
# Run from repo root after build.sh trial, with the retained test in the checkout.
set -euxo pipefail
home=$(realpath "$(dirname "$0")")
src=$home/rs/crates/codec/src/entropy
cp crates/codec/src/entropy/tests.rs "$src/tests.rs"
cd "$home/rs"
export CARGO_TARGET_DIR=$home/cargo
export CARGO_ENCODED_RUSTFLAGS=''
export CARGO_BUILD_JOBS=6
check=(cargo test --release --locked -p zxc-codec --lib)
"${check[@]}" --features merge-simd
"${check[@]}" --no-default-features

exe=$("${check[@]}" --features merge-simd --no-run --message-format=json |
    python3 -c 'import json, sys; [exe] = [x["executable"] for x in map(json.loads, sys.stdin) if x.get("profile", {}).get("test") and x.get("executable")]; print(exe)')
for cpu in Conroe Nehalem; do
    qemu-x86_64 -cpu "$cpu" "$exe" bitmap
done

# AddressSanitizer instruments the Rust codec and fearless_simd, not std.
CARGO_ENCODED_RUSTFLAGS=-Zsanitizer=address CARGO_TARGET_DIR=$home/asan \
    "${check[@]}" --target x86_64-unknown-linux-gnu --features merge-simd entropy::tests
