#!/usr/bin/env bash
# Run from repo root, with merge.patch present beside this script.
set -euxo pipefail
here=$(realpath doc/profiling/decode-replay-data)
out=$(realpath "$(dirname "$0")")
pin=3ce5ff5b4c2116ad7515a579feedd2a1c445d20a
rs=$out/rs
label=$1
git merge-base --is-ancestor 845a76c6a9873535ccf6e3d3a5cab98a049eb165 "$pin"
mkdir -p "$rs"
git archive "$pin" | tar -x -C "$rs"
cd "$rs"
case "$label" in
    base) ;;
    trial) patch -p1 < "$out/merge.patch" ;;
    *) exit 2 ;;
esac
export CARGO_TARGET_DIR="$out/cargo"
rustc -Vv
cargo -V
export CARGO_ENCODED_RUSTFLAGS=''
cargo build --release --locked -p zxc-cli
cp "$CARGO_TARGET_DIR/release/zxc" "$out/cli-$label"
cargo build --release --locked -p zxc-cli --no-default-features
cp "$CARGO_TARGET_DIR/release/zxc" "$out/cli-scalar-$label"
mkdir -p crates/codec/src/bin
cp "$here/replay.rs" crates/codec/src/bin/replay.rs
cat "$here/section-entry.rs" >> crates/codec/src/block.rs
printf '\n#[doc(hidden)]\npub use block::replay_huf;\n' >> crates/codec/src/lib.rs
export CARGO_ENCODED_RUSTFLAGS=$'--cfg\x1freplay_perf\x1f-Cdebuginfo=line-tables-only'
export CARGO_PROFILE_RELEASE_STRIP=none
cargo build --release --locked -p zxc-codec --features merge-simd --bin replay
cp "$CARGO_TARGET_DIR/release/replay" "$out/replay-$label"
cargo build --release --locked -p zxc-codec --no-default-features --bin replay
cp "$CARGO_TARGET_DIR/release/replay" "$out/replay-scalar-$label"
sha256sum "$out"/{cli,replay}{,-scalar}-"$label"
