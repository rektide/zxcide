#!/usr/bin/env python3
"""Offline attribution for perf script exports; does not run a decoder."""
from collections import Counter
from pathlib import Path
import re
import subprocess as sp
import sys


build, profiles = map(Path, sys.argv[1:])
ip = re.compile(r'^\s*(\d+)\s+([0-9a-f]+)\s+(.*?)\s+\((.*)\)$')
print('profile\tsample_ips\tunknown_symbols\tunknown_lines_or_line0\tcategory\tsamples\tpct_of_all')
for path in sorted(profiles.glob('*.samples')):
    label = path.stem.split('-', 2)[2]
    elf = build / f'replay-{label}'
    load = sp.check_output(['readelf', '-lW', elf], text=True)
    off, vaddr = next((int(r[1], 16), int(r[2], 16)) for ln in load.splitlines()
                      if (r := ln.split()) and r[0] == 'LOAD' and 'E' in r[6:])
    text = path.read_text().splitlines()
    count, addresses = Counter(), Counter()
    missing_line = total = 0
    for i, row in enumerate(text):
        if not (m := ip.fullmatch(row)):
            continue
        assert int(m[1]) == 500_000
        total += 1
        line = text[i + 1] if i + 1 < len(text) else ''
        if not line or ip.fullmatch(line) or re.search(r'\?\?|\[unknown\]|:0$', line):
            missing_line += 1
        symbol = m[3].partition('+0x')[0]
        if symbol == '[unknown]':
            count['unknown'] += 1
        if ('entropy::flat::unpack' in symbol or symbol == 'zxc_pivco_decode_core') and (dso := m[4].rpartition('+0x'))[1]:
            if Path(dso[0]).name == elf.name:
                addresses[int(dso[2], 16) + vaddr - off] += 1
    addr2line = sp.check_output(['llvm-addr2line', '-e', elf, '-a', '-f', '-C', '-i'], text=True,
                                input=''.join(f'{addr:#x}\n' for addr in addresses))
    for entry in re.split(r'(?m)^0x', addr2line)[1:]:
        addr = int(entry.splitlines()[0], 16)
        if label == 'c':
            category = next((fn for fn in ('zxc_pivco_merge', 'zxc_pivco_unpack_flat', 'zxc_pivco_emit_leaf_pair')
                             if fn in entry), 'other_core')
        else:
            width = re.search(r'groups<(\d+),', entry)
            category = f'flat_width_{width[1]}' if width else 'flat_unclassified'
        count[category] += addresses.pop(addr)
    assert total > 0 and not addresses, path
    for category, n in sorted(count.items()):
        print(f'{path.stem}\t{total}\t{count["unknown"]}\t{missing_line}\t{category}\t{n}\t{100*n/total:.2f}')
