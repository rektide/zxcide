#!/usr/bin/env python3
"""Select the Huffman trial and A/A controls in the existing fixed-archive CLI harness."""
from pathlib import Path

path = Path('doc/profiling/decode-pool-data/bench.py').resolve()
src = path.read_text()
changes = [
    ('def invoke(label, workers, name):', '''
cases = {k: [f'{k}.zxc'] for k in ('single', 'sao', 'mozilla')}
comparisons = [(k, w, 'base', other) for k in cases for w in (1, 8) for other in ('trial', 'base')]
def invoke(label, workers, name):'''),
    ('m["plain"]["bytes"]*1000', 'archives[cases[case][0]][2]*1000'),
    ("group[3].append(f'{st.median(delta(1)):+.1f}%')", '''
        cpu = delta(1)
        lo, hi = interval(cpu)
        size = archives[cases[case][0]][2]
        a_cpu, b_cpu = (st.median(p[pos][1] for p in pairs)*1000/size for pos in (0, 1))
        group[3].append(f'{a_cpu:.3f} → {b_cpu:.3f}; {st.median(cpu):+.1f}% [{lo:+.1f},{hi:+.1f}]')'''.lstrip()),
    ('| Paired CPU Δ |', '| Child CPU s/GB; paired Δ [CI] |'),
    ("raw['cpu_governors'] =", '''raw['cpu_siblings'] = {str(n): Path(f'/sys/devices/system/cpu/cpu{n}/topology/thread_siblings_list').read_text().strip() for n in raw['affinity']}
raw['boost'] = Path('/sys/devices/system/cpu/cpufreq/boost').read_text().strip()
raw['cpu_governors'] ='''),
]
for old, new in changes:
    assert src.count(old) == 1, old
    src = src.replace(old, new)
exec(compile(src, str(path), 'exec'), {'__name__': '__main__', '__file__': str(path)})
