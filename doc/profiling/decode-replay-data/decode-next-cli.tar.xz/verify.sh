#!/usr/bin/env bash
# Verify the retained trial without reusing the built CLI or benchmark archive output.
set -euxo pipefail
run=$(realpath "$(dirname "$0")")
export CARGO_TARGET_DIR="$run/cargo"
export TMPDIR="$run/tmp"
export CARGO_ENCODED_RUSTFLAGS=''
cargo fmt --all -- --check
cargo nextest run --locked --workspace --release
cargo nextest run --locked -p zxc-codec --release --no-default-features
cargo clippy --locked -p zxc-codec --all-targets -- -D warnings -A clippy::new_instead_of_clear
cargo build --release --locked -p zxc-cli
cp "$CARGO_TARGET_DIR/release/zxc" "$run/cli-retained"
sha256sum "$run/cli-retained"

# Tree::new is also used by the encoder. Both portable CLIs must write
# identical Dense archives for several different plaintext distributions.
for name in multiblock_checksum text_64k_bs2m spl_tok_huffman_l7; do
    plain="tests/conformance/v9/valid/$name.expected"
    for v in base retained; do
        "$run/cli-$v" encode --mode dense "$plain" > "$run/tmp/$v.$name.zxc"
    done
    cmp "$run/tmp/base.$name.zxc" "$run/tmp/retained.$name.zxc"
    sha256sum "$run/tmp/retained.$name.zxc"
done
