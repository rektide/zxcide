#!/usr/bin/env python3
"""Count checked fixed-archive PivCo run shapes without timing or emitting symbols."""
from collections import Counter, deque
import json
from pathlib import Path
import sys


def runs(section, n):
    # Independent canonical trie, with positive list indices and leaf symbols
    # represented by bitwise complement. Missing children are None.
    lengths = [(d, i*2+j) for i, b in enumerate(section[:128])
               for j, d in enumerate((b&15, b>>4)) if d]
    assert all(d <= 11 for d, _ in lengths)
    assert sum(1 << (11-d) for d, _ in lengths) == 2048 or (len(lengths) == 1 and lengths[0][0] == 1)
    tree = [[None, None]]
    code = prev = 0
    for d, s in sorted(lengths):
        code <<= d - prev
        pos = 0
        for shift in range(d-1, 0, -1):
            side = (code >> shift)&1
            if tree[pos][side] is None:
                tree[pos][side] = len(tree)
                tree.append([None, None])
            pos = tree[pos][side]
            assert pos >= 0
        assert tree[pos][code&1] is None
        tree[pos][code&1] = ~s
        code += 1
        prev = d
    height = [None]*len(tree)
    for i in reversed(range(len(tree))):
        a, b = (None if j is None else 0 if j < 0 else height[j] for j in tree[i])
        if a is not None and a == b:
            height[i] = a+1
    q = deque([(0,n)])
    off = 128
    while q:
        i, n = q.popleft()
        if not n:
            continue
        assert i is not None
        if i < 0:
            yield 'leaf', n, 0
            continue
        h = height[i]
        size = (n*(h or 1) + 7)//8
        run = section[off:off+size]
        assert len(run) == size
        off += size
        if h:
            yield f'flat-{h}', n, size
        else:
            tail = n%8
            ones = int.from_bytes(run, 'little').bit_count()
            if tail:
                ones -= (run[-1] >> tail).bit_count()
            assert 0 <= ones <= n
            yield 'uniform' if ones in (0,n) else 'mixed', n, size
            q.extend(zip(tree[i], (n-ones, ones)))
    assert off == len(section)


def main(archive, indexes):
    data = archive.read_bytes()
    for idx in indexes:
        cs = {}
        total = 0
        for row in idx.read_text().splitlines():
            off, length, n = map(int, row.split())
            total += n
            for kind, count, coded in runs(data[off:off+length], n):
                tally = cs.setdefault(kind, Counter())
                tally.update(runs=1, symbols=count, coded_bytes=coded, runs_below_32=count<32,
                             symbols_in_runs_at_least_128=count if count>=128 else 0)
        assert sum(c['symbols'] for k,c in cs.items() if k.startswith('flat-') or k=='leaf') == total
        print(json.dumps(dict(index=idx.name, symbols=total, runs_by_kind=cs), sort_keys=True))


if __name__ == '__main__':
    data, *indexes = map(Path, sys.argv[1:])
    main(data, indexes)
