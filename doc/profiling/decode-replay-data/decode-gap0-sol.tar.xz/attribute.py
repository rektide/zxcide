#!/usr/bin/env python3
"""Classify sampled leaf IPs in the pinned replay builds; caller only for libc."""
from collections import Counter
import json
from math import comb
from pathlib import Path
import re
import statistics as st
import sys

FRAME = re.compile(r'^\s+([0-9a-f]+) (.*)$')
PERIOD = re.compile(r'^\s+(\d+)\s*$')
RANGES = {
    'a': (range(149, 162), range(145, 147), 209),
    'b': (range(192, 206), range(147, 149), 224),
}


def frames(sample):
    result = []
    for ln in sample.splitlines()[1:]:
        if (m := FRAME.match(ln)):
            ip, name = m.groups()
            result.append([ip, name, ''])
        elif result:
            result[-1][2] = ln.strip().removesuffix(' (inlined)')
    return result


def lines(contents, file):
    pat = re.compile(rf'\b{re.escape(file)}:(\d+)(?::\d+)?$')
    return {int(m[1]) for row in contents if (m := pat.search(row[2]))}


def classify(label, contents):
    if not contents:
        return 'unassigned', ''
    ip, leaf, _ = contents[0]
    current = [fr for fr in contents if fr[0] == ip]
    name = ' '.join(fr[1] for fr in current)
    is_libc = 'libc.so' in leaf
    if is_libc:
        name += ' ' + ' '.join(fr[1] for fr in contents[len(current):])
    locations = contents if is_libc else current
    if label == 'c':
        h = lines(locations, 'zxc_huffman.c')
        d = lines(locations, 'zxc_decompress.c')
        if 'zxc_pivco_merge' in name:
            return 'mixed gather', ''
        if 'zxc_pivco_unpack_flat' in name:
            # AVX2 handles 2..6 in one common loop; no width can be inferred at its IPs.
            return 'flat/leaf-pair', 'flat'
        if 'zxc_pivco_emit_leaf_pair' in name:
            return 'flat/leaf-pair', 'leaf-pair'
        if 'zxc_pivco_tree_build' in name or 'zxc_huf_unpack_lengths' in name:
            return 'table setup', ''
        if ('zxc_pivco_popcnt' in name or h.intersection(range(2216, 2229))) and 'zxc_pivco_decode_core' in name:
            return 'bitmap counts', ''
        if '__memset' in leaf and 'zxc_pivco_decode_core' in name:
            return 'leaf fill', ''
        if 'zxc_pivco_decode_core' in name or 'zxc_huf_decode_section' in name:
            return 'entropy residual', ''
        if 'XXH' in name or 'rapidhash' in name or 'rapid_mix' in name or 'checksum' in name:
            return 'checksum', ''
        if 'zxc_decode_block_spl_impl' in name and d.intersection(range(986, 1178)):
            return 'reconstruction', ''
        if ('zxc_decode_block_spl' in name or 'zxc_decompress_chunk' in name or
                any('zxc_decompress.c:' in fr[2] for fr in current)):
            return 'block outside entropy', ''
    else:
        if 'entropy::merge' in name or 'gather' in name and 'zxc_codec::entropy' in name:
            return 'mixed gather', ''
        if 'entropy::flat' in name or any('flat.rs:' in fr[2] for fr in current):
            m = re.search(r'\bgroups<(\d+),', name)
            w = m[1] if m else '3' if 'three_groups' in name else '?'
            return 'flat/leaf-pair', 'width ' + w
        counts, fill, copyline = RANGES[label]
        ent = lines(locations, 'entropy.rs')
        canon = lines(locations, 'canonical.rs') if label == 'b' else set()
        decode = '::decode_into' in name and 'zxc_codec::entropy' in name or 'canonical::decode_inline' in name
        if decode and is_libc and ('memmove' in leaf or 'memcpy' in leaf):
            # Confirm these specific callers are the memcpy calls for copy-back
            # using objdump. DWARF usually gives their return addresses, not
            # entropy.rs source lines in this release profile. The inlined
            # copy_from_slice<u8> also distinguishes them from Vec reallocations.
            if re.search(r'copy_from_slice<u8>|copy_from_slice_impl<u8>', name):
                return 'copy-back', ''
        if decode and copyline in ent:
            return 'copy-back', ''
        if decode and (ent.intersection(counts) or 'count_ones' in name or 'map::map_fold' in name):
            return 'bitmap counts', ''
        if decode and label == 'b' and ('bitmap_ones' in name or 148 in canon):
            return 'bitmap counts', ''
        if 'Tree>::new' in name or 'RawVec<zxc_codec::entropy::Node>' in name:
            return 'table setup', ''
        if decode and (canon.intersection(range(34, 114)) or canon.intersection(range(137, 144))):
            return 'table setup', ''
        if decode and is_libc and '__memset' in leaf:
            # Residual initialization (including some tree/setup fill) is
            # separate; don't silently charge all memsets to leaf materializing.
            if ent.intersection(fill) or 159 in canon:
                return 'leaf fill', ''
            return 'entropy residual', ''
        if decode:
            return 'entropy residual', ''
        if 'reconstruct' in name or 'Spl16::batch' in name or 'zxc_codec::block::extra' in name:
            return 'reconstruction', ''
        if 'checksum' in name or 'xxh' in name.lower() or 'rapidhash' in name or 'rapid_mix' in name:
            return 'checksum', ''
        if 'zxc_codec::block' in name:
            return 'block outside entropy', ''
    return ('other libc' if is_libc else 'unassigned'), ''


def interval(xs):
    xs = sorted(xs)
    assert len(xs) == 24 and sum(comb(24,k) for k in range(7)) * 40 <= 2**24
    return xs[6], xs[17]


def main(out):
    raw = json.loads((out/'counts.json').read_text())
    report = {}
    for name, case in raw['cases'].items():
        summary = report[name] = {}
        for label in 'abc':
            counts, subcount, unknown = Counter(), Counter(), Counter()
            data = (out/f'{name}-{label}.samples').read_text()
            assert not re.search(r'PERF_RECORD_LOST|\bLOST\b', data)
            for chunk in re.split(r'(?m)(?=^\s*\d+ *$)', data):
                first = chunk.splitlines()[0] if chunk.splitlines() else ''
                if not (p := PERIOD.fullmatch(first)):
                    continue
                n = int(p[1])
                contents = frames(chunk)
                category, sub = classify(label, contents)
                counts[category] += n
                if sub:
                    subcount[sub] += n
                if category in ('entropy residual', 'unassigned', 'block outside entropy', 'other libc') and contents:
                    leaf = contents[0][1]
                    short = re.sub(r' \(/.*\)$', '', leaf)
                    unknown[category + '\t' + short[:180]] += n
            norm = case['units']*case['repeats']
            stats = case['rounds']
            med = {k: st.median(row[label][k] for row in stats)/norm for k in ('cycles:u','instructions:u','thread_cpu_ns')}
            contrasts = {}
            for k in med:
                ds = [100*(row[label][k]/row['a'][k]-1) for row in stats]
                contrasts[k] = [st.median(ds), *interval(ds)]
            total = sum(counts.values())
            assert total > 0, (name,label,total)
            assert total % 500_000 == 0
            summary[label] = dict(samples=total//500_000, **med, paired_vs_a=contrasts,
                                  samples_by_phase={k:v//500_000 for k,v in counts.items()},
                                  cycles_est={k:v/total*med['cycles:u'] for k,v in counts.items()},
                                  flat_samples={k:v//500_000 for k,v in subcount.items()},
                                  residual={k:v//500_000 for k,v in unknown.most_common(40)})
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]))
