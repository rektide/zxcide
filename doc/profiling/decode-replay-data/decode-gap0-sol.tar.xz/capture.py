#!/usr/bin/env python3
"""Capture counts and sampling separately using the existing resident replay."""
import argparse
from contextlib import ExitStack
import fcntl
from itertools import permutations
import json
from pathlib import Path
import random
import subprocess as sp
import sys

src = Path('doc/profiling/decode-replay-data/perf.py').resolve()
sys.path.insert(0, str(src.parent))
import perf

# Keep the same attach/enable/ack protocol, adding bounded DWARF callchains
# for libc callers. Only recording uses these callchains, not timed counts.
old = "'-c', str(PERIOD), '-o', str(output)"
assert src.read_text().count(old) == 1
record = {'__name__': 'record', '__file__': str(src)}
exec(compile(src.read_text().replace(old, old + ", '--call-graph', 'dwarf,1024'"), str(src), 'exec'), record)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for field in ('build', 'archive', 'out'):
        p.add_argument(field, type=lambda s: Path(s).resolve())
    p.add_argument('--cpu', type=int, default=3)
    args = p.parse_args()
    labels = ('a', 'b', 'c')
    args.out.mkdir()
    binary = {k: args.build / f'replay-{k}' for k in labels}
    manifest = json.loads(perf.MANIFEST.read_text())
    assert perf.identity(args.archive) == {k: manifest['single'][k] for k in ('bytes', 'sha256')}
    perf.LABELS = labels
    raw = dict(cpu=args.cpu, binaries={k: perf.identity(v) for k, v in binary.items()},
               archive=perf.identity(args.archive), cases={})
    with Path('.test-agent/zxc-perf.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        raw['before'] = perf.snapshot(args.cpu)
        blocks, idx = perf.capture(args.archive, args.out)
        cases = [
            ('lit', idx['lit'], 5, 64, None, 'bad-table-rejected'),
            ('block', dict(count=blocks, units=manifest['plain']['bytes']), 1, 12, manifest['plain'], 'bad-checksum-rejected'),
        ]
        for name, case, repeats, profile_repeats, digest, reject in cases:
            case.update(repeats=repeats, reject=reject)
            cmd = {k: ['taskset', '-c', str(args.cpu), str(v), 'serve', str(args.archive)] +
                   ([case['index']['path']] if 'index' in case else []) for k, v in binary.items()}
            case['exact'] = perf.verify(list(cmd.values()), args.out, case, digest)
            rng = random.Random(160331 if name == 'lit' else 66149)
            # Four runs of all six orders, shuffled within each set.
            order = [perm for _ in range(4) for perm in rng.sample(list(permutations(labels)), 6)]
            case['before'] = perf.snapshot(args.cpu)
            with ExitStack() as stack:
                workers = {}
                for k, c in cmd.items():
                    worker = stack.enter_context(sp.Popen(c, stdin=sp.PIPE, stdout=sp.PIPE))
                    stack.callback(worker.stdin.close)
                    workers[k] = worker
                ready = {k: w.stdout.readline().decode().split() for k, w in workers.items()}
                assert all(row == ready['a'] for row in ready.values()), ready
                assert ready['a'][:3] == ['ready', str(case['count']), str(case['units'])] and ready['a'][-1] == reject
                case['ready'] = ready
                case['warm'] = {k: perf.request(w, repeats) for k, w in workers.items()}
                case['rounds'] = [{k: perf.measure(workers[k], repeats) for k in perm} for perm in order]
                case['profiles'] = {}
                for k in rng.sample(list(labels), len(labels)):
                    path = args.out / f'{name}-{k}.perf.data'
                    result = record['measure'](workers[k], profile_repeats, path)
                    case['profiles'][k] = dict(path=str(path), repeats=profile_repeats, **result)
                for w in workers.values():
                    w.stdin.close()
                    assert w.wait(timeout=10) == 0
            case['after'] = perf.snapshot(args.cpu)
            raw['cases'][name] = case
            (args.out/'counts.json').write_text(json.dumps(raw, indent=2)+'\n')
            print(name, 'complete', flush=True)


if __name__ == '__main__':
    main()
